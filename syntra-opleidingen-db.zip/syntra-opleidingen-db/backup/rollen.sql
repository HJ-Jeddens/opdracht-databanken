/* =====================================================================
   rollen.sql

   Rollen bestaan op serverniveau, niet in een database. Ze zitten dus
   NIET in een pg_dump van syntra_opleidingen.

   Draai dit script op een nieuwe server voor je de backup herstelt, of
   voer gewoon sql/07_rollen_en_rechten.sql uit: dat maakt dezelfde
   rollen aan en kent meteen alle rechten toe.
   ===================================================================== */

CREATE ROLE syntra_web        NOLOGIN;
CREATE ROLE syntra_lesgever   NOLOGIN;
CREATE ROLE syntra_medewerker NOLOGIN;
CREATE ROLE syntra_admin      NOLOGIN;

GRANT syntra_medewerker TO syntra_admin;

-- Loginrol voor de website. Geef die in productie een echt wachtwoord.
CREATE ROLE website_gebruiker LOGIN PASSWORD 'website';
GRANT syntra_web TO website_gebruiker;
