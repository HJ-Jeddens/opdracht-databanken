--
-- PostgreSQL database dump
--

\restrict HERKB2g80SIo4zlcpesCJSrnKCDa7jX9ZrNCSQlViVkNGZkcgolTJPMYQ2YZGaZ

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: fn_aantal_ingeschreven(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_aantal INT;
BEGIN
    SELECT COUNT(*)
    INTO   v_aantal
    FROM   inschrijving
    WHERE  periode_id = p_periode_id
      AND  status IN ('aangevraagd', 'bevestigd', 'afgewerkt');

    RETURN v_aantal;
END;
$$;


ALTER FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) OWNER TO postgres;

--
-- Name: FUNCTION fn_aantal_ingeschreven(p_periode_id integer); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) IS 'Aantal actieve inschrijvingen voor een opleidingsperiode.';


--
-- Name: fn_leeftijd(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_leeftijd(p_geboortedatum date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_geboortedatum IS NULL THEN
        RETURN NULL;
    END IF;

    RETURN EXTRACT(YEAR FROM AGE(CURRENT_DATE, p_geboortedatum));
END;
$$;


ALTER FUNCTION public.fn_leeftijd(p_geboortedatum date) OWNER TO postgres;

--
-- Name: fn_log_inschrijving_status(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_log_inschrijving_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO inschrijving_log (inschrijving_id, oude_status, nieuwe_status)
        VALUES (NEW.inschrijving_id, NULL, NEW.status);

    ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO inschrijving_log (inschrijving_id, oude_status, nieuwe_status)
        VALUES (NEW.inschrijving_id, OLD.status, NEW.status);
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_log_inschrijving_status() OWNER TO postgres;

--
-- Name: fn_module_geslaagd(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_module_geslaagd(p_inschrijving_module_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_vrijstelling BOOLEAN;
    v_beste_score  DECIMAL(5,2);
BEGIN
    SELECT vrijstelling
    INTO   v_vrijstelling
    FROM   inschrijving_module
    WHERE  inschrijving_module_id = p_inschrijving_module_id;

    IF v_vrijstelling IS NULL THEN
        RETURN NULL;
    ELSIF v_vrijstelling THEN
        RETURN TRUE;
    END IF;

    SELECT MAX(score)
    INTO   v_beste_score
    FROM   evaluatie
    WHERE  inschrijving_module_id = p_inschrijving_module_id;

    RETURN COALESCE(v_beste_score >= 50, FALSE);
END;
$$;


ALTER FUNCTION public.fn_module_geslaagd(p_inschrijving_module_id integer) OWNER TO postgres;

--
-- Name: fn_openstaand_saldo(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_openstaand_saldo(p_inschrijving_id integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_te_betalen DECIMAL(8,2);
    v_betaald    DECIMAL(8,2);
BEGIN
    SELECT te_betalen
    INTO   v_te_betalen
    FROM   inschrijving
    WHERE  inschrijving_id = p_inschrijving_id;

    IF v_te_betalen IS NULL THEN
        RETURN NULL;
    END IF;

    -- COALESCE: zonder betalingen geeft SUM() NULL terug, geen 0.
    SELECT COALESCE(SUM(bedrag), 0)
    INTO   v_betaald
    FROM   betaling
    WHERE  inschrijving_id = p_inschrijving_id;

    RETURN v_te_betalen - v_betaald;
END;
$$;


ALTER FUNCTION public.fn_openstaand_saldo(p_inschrijving_id integer) OWNER TO postgres;

--
-- Name: fn_vrije_plaatsen(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_max  INT;
    v_bezet INT;
BEGIN
    SELECT max_cursisten
    INTO   v_max
    FROM   opleidingsperiode
    WHERE  periode_id = p_periode_id;

    IF v_max IS NULL THEN
        RETURN NULL;                 -- periode bestaat niet
    END IF;

    v_bezet := fn_aantal_ingeschreven(p_periode_id);

    -- GREATEST voorkomt een negatief getal als de capaciteit ooit
    -- handmatig verlaagd zou worden.
    RETURN GREATEST(0, v_max - v_bezet);
END;
$$;


ALTER FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) OWNER TO postgres;

--
-- Name: fn_zet_gewijzigd_op(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_zet_gewijzigd_op() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.gewijzigd_op := now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_zet_gewijzigd_op() OWNER TO postgres;

--
-- Name: sp_betaling_registreren(integer, numeric, character varying, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_betaling_registreren(IN p_inschrijving_id integer, IN p_bedrag numeric, IN p_methode character varying, IN p_referentie character varying DEFAULT NULL::character varying, IN p_datum date DEFAULT CURRENT_DATE)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_saldo DECIMAL(8,2);
BEGIN
    v_saldo := fn_openstaand_saldo(p_inschrijving_id);

    IF v_saldo IS NULL THEN
        RAISE EXCEPTION 'Onbekende inschrijving %.', p_inschrijving_id;
    END IF;

    IF p_bedrag > v_saldo THEN
        RAISE EXCEPTION 'Bedrag % is hoger dan het openstaande saldo van %.',
                        p_bedrag, v_saldo;
    END IF;

    INSERT INTO betaling (inschrijving_id, bedrag, betaaldatum, methode, referentie)
    VALUES (p_inschrijving_id, p_bedrag, p_datum, p_methode,
            COALESCE(p_referentie,
                     'BET-' || p_inschrijving_id || '-' || TO_CHAR(now(), 'YYYYMMDDHH24MISS')));

    RAISE NOTICE 'Betaling van % geregistreerd. Nog openstaand: %.',
                 p_bedrag, fn_openstaand_saldo(p_inschrijving_id);
END;
$$;


ALTER PROCEDURE public.sp_betaling_registreren(IN p_inschrijving_id integer, IN p_bedrag numeric, IN p_methode character varying, IN p_referentie character varying, IN p_datum date) OWNER TO postgres;

--
-- Name: sp_categorie_toevoegen(character varying, character varying, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_categorie_toevoegen(IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying DEFAULT NULL::character varying, IN p_afbeelding_url character varying DEFAULT NULL::character varying, IN p_volgorde integer DEFAULT 0)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id INT;
BEGIN
    IF p_naam IS NULL OR TRIM(p_naam) = '' THEN
        RAISE EXCEPTION 'De naam van de categorie is verplicht.';
    END IF;

    IF EXISTS (SELECT 1 FROM categorie WHERE slug = p_slug) THEN
        RAISE EXCEPTION 'Er bestaat al een categorie met slug "%".', p_slug;
    END IF;

    INSERT INTO categorie (naam, slug, omschrijving, afbeelding_url, volgorde)
    VALUES (TRIM(p_naam), p_slug, p_omschrijving, p_afbeelding_url, p_volgorde)
    RETURNING categorie_id INTO v_id;

    RAISE NOTICE 'Categorie "%" toegevoegd met id %.', p_naam, v_id;
END;
$$;


ALTER PROCEDURE public.sp_categorie_toevoegen(IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) OWNER TO postgres;

--
-- Name: sp_cursist_toevoegen(character varying, character varying, character varying, character varying, date, character, character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_cursist_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying DEFAULT NULL::character varying, IN p_geboortedatum date DEFAULT NULL::date, IN p_rijksregisternr character DEFAULT NULL::bpchar, IN p_adres character varying DEFAULT NULL::character varying, IN p_postcode character varying DEFAULT NULL::character varying, IN p_gemeente character varying DEFAULT NULL::character varying, IN p_hoogste_diploma character varying DEFAULT NULL::character varying, IN p_wachtwoord character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_persoon_id INT;
BEGIN
    SELECT persoon_id
    INTO   v_persoon_id
    FROM   persoon
    WHERE  LOWER(email) = LOWER(p_email);

    IF v_persoon_id IS NULL THEN
        INSERT INTO persoon (voornaam, familienaam, email, telefoon, geboortedatum,
                             rijksregisternr, adres, postcode, gemeente)
        VALUES (TRIM(p_voornaam), TRIM(p_familienaam), p_email, p_telefoon,
                p_geboortedatum, p_rijksregisternr, p_adres, p_postcode, p_gemeente)
        RETURNING persoon_id INTO v_persoon_id;
    END IF;

    IF EXISTS (SELECT 1 FROM cursist WHERE cursist_id = v_persoon_id) THEN
        RAISE EXCEPTION 'Deze persoon (%) is al geregistreerd als cursist.', p_email;
    END IF;

    INSERT INTO cursist (cursist_id, cursistnummer, hoogste_diploma, wachtwoord_hash)
    VALUES (v_persoon_id,
            'C' || LPAD(v_persoon_id::TEXT, 5, '0'),
            p_hoogste_diploma,
            CASE WHEN p_wachtwoord IS NULL
                 THEN NULL
                 ELSE crypt(p_wachtwoord, gen_salt('bf'))
            END);

    RAISE NOTICE 'Cursist % % toegevoegd met nummer C%.',
                 p_voornaam, p_familienaam, LPAD(v_persoon_id::TEXT, 5, '0');
END;
$$;


ALTER PROCEDURE public.sp_cursist_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_geboortedatum date, IN p_rijksregisternr character, IN p_adres character varying, IN p_postcode character varying, IN p_gemeente character varying, IN p_hoogste_diploma character varying, IN p_wachtwoord character varying) OWNER TO postgres;

--
-- Name: sp_evaluatie_registreren(integer, character varying, numeric, character varying, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying DEFAULT NULL::character varying, IN p_feedback character varying DEFAULT NULL::character varying, IN p_datum date DEFAULT CURRENT_DATE)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_im_id       INT;
    v_lesgever_id INT;
    v_poging      INT;
BEGIN
    SELECT im.inschrijving_module_id
    INTO   v_im_id
    FROM   inschrijving_module im
    JOIN   periode_module      pm ON pm.periode_module_id = im.periode_module_id
    JOIN   module              m  ON m.module_id = pm.module_id
    WHERE  im.inschrijving_id = p_inschrijving_id
      AND  m.code = p_module_code;

    IF v_im_id IS NULL THEN
        RAISE EXCEPTION 'Module "%" hoort niet bij inschrijving %.',
                        p_module_code, p_inschrijving_id;
    END IF;

    IF p_lesgever_email IS NOT NULL THEN
        SELECT l.lesgever_id
        INTO   v_lesgever_id
        FROM   lesgever l
        JOIN   persoon  p ON p.persoon_id = l.lesgever_id
        WHERE  LOWER(p.email) = LOWER(p_lesgever_email);
    END IF;

    SELECT COALESCE(MAX(poging), 0) + 1
    INTO   v_poging
    FROM   evaluatie
    WHERE  inschrijving_module_id = v_im_id;

    INSERT INTO evaluatie (inschrijving_module_id, evaluatiedatum, score,
                           poging, feedback, lesgever_id)
    VALUES (v_im_id, p_datum, p_score, v_poging, p_feedback, v_lesgever_id);

    RAISE NOTICE 'Evaluatie geregistreerd: module %, poging %, score % (%).',
                 p_module_code, v_poging, p_score,
                 CASE WHEN p_score >= 50 THEN 'geslaagd' ELSE 'niet geslaagd' END;
END;
$$;


ALTER PROCEDURE public.sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying, IN p_feedback character varying, IN p_datum date) OWNER TO postgres;

--
-- Name: sp_inschrijven(character varying, character varying, numeric, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_inschrijven(IN p_email character varying, IN p_periode_code character varying, IN p_korting numeric DEFAULT 0, IN p_korting_tekst character varying DEFAULT NULL::character varying, IN p_opmerking character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_cursist_id     INT;
    v_periode_id     INT;
    v_status         VARCHAR(15);
    v_prijs          DECIMAL(8,2);
    v_vrij           INT;
    v_inschrijving_id INT;
BEGIN
    SELECT c.cursist_id
    INTO   v_cursist_id
    FROM   cursist c
    JOIN   persoon p ON p.persoon_id = c.cursist_id
    WHERE  LOWER(p.email) = LOWER(p_email)
      AND  c.actief;

    IF v_cursist_id IS NULL THEN
        RAISE EXCEPTION 'Geen actieve cursist gevonden met e-mailadres "%".', p_email;
    END IF;

    -- FOR UPDATE vergrendelt de rij tot het einde van de transactie.
    SELECT periode_id, status, prijs
    INTO   v_periode_id, v_status, v_prijs
    FROM   opleidingsperiode
    WHERE  code = p_periode_code
    FOR UPDATE;

    IF v_periode_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende opleidingsperiode "%".', p_periode_code;
    END IF;

    IF v_status NOT IN ('gepland', 'open') THEN
        RAISE EXCEPTION 'Periode "%" staat op status "%" en is niet open voor inschrijvingen.',
                        p_periode_code, v_status;
    END IF;

    v_vrij := fn_vrije_plaatsen(v_periode_id);
    IF v_vrij <= 0 THEN
        RAISE EXCEPTION 'Periode "%" is volzet.', p_periode_code;
    END IF;

    IF EXISTS (SELECT 1 FROM inschrijving
               WHERE cursist_id = v_cursist_id AND periode_id = v_periode_id) THEN
        RAISE EXCEPTION 'Cursist % is al ingeschreven voor periode "%".',
                        p_email, p_periode_code;
    END IF;

    INSERT INTO inschrijving (cursist_id, periode_id, te_betalen, korting, opmerking)
    VALUES (v_cursist_id, v_periode_id,
            GREATEST(v_prijs - COALESCE(p_korting, 0), 0),
            p_korting_tekst, p_opmerking)
    RETURNING inschrijving_id INTO v_inschrijving_id;

    -- De cursist volgt standaard alle modules van de periode.
    INSERT INTO inschrijving_module (inschrijving_id, periode_module_id)
    SELECT v_inschrijving_id, pm.periode_module_id
    FROM   periode_module pm
    WHERE  pm.periode_id = v_periode_id;

    IF fn_vrije_plaatsen(v_periode_id) = 0 THEN
        UPDATE opleidingsperiode SET status = 'volzet' WHERE periode_id = v_periode_id;
        RAISE NOTICE 'Periode "%" is nu volzet.', p_periode_code;
    END IF;

    RAISE NOTICE 'Inschrijving % aangemaakt voor % in periode %. Nog % plaatsen vrij.',
                 v_inschrijving_id, p_email, p_periode_code, fn_vrije_plaatsen(v_periode_id);
END;
$$;


ALTER PROCEDURE public.sp_inschrijven(IN p_email character varying, IN p_periode_code character varying, IN p_korting numeric, IN p_korting_tekst character varying, IN p_opmerking character varying) OWNER TO postgres;

--
-- Name: sp_inschrijving_annuleren(integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_inschrijving_annuleren(IN p_inschrijving_id integer, IN p_reden character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_periode_id INT;
BEGIN
    UPDATE inschrijving
    SET    status    = 'geannuleerd',
           opmerking = COALESCE(opmerking || ' | ', '') || COALESCE(p_reden, 'Geannuleerd')
    WHERE  inschrijving_id = p_inschrijving_id
      AND  status <> 'geannuleerd'
    RETURNING periode_id INTO v_periode_id;

    IF v_periode_id IS NULL THEN
        RAISE EXCEPTION 'Inschrijving % bestaat niet of was al geannuleerd.',
                        p_inschrijving_id;
    END IF;

    UPDATE opleidingsperiode
    SET    status = 'open'
    WHERE  periode_id = v_periode_id
      AND  status = 'volzet'
      AND  fn_vrije_plaatsen(v_periode_id) > 0;

    RAISE NOTICE 'Inschrijving % geannuleerd.', p_inschrijving_id;
END;
$$;


ALTER PROCEDURE public.sp_inschrijving_annuleren(IN p_inschrijving_id integer, IN p_reden character varying) OWNER TO postgres;

--
-- Name: sp_inschrijving_bevestigen(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_inschrijving_bevestigen(IN p_inschrijving_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE inschrijving
    SET    status = 'bevestigd'
    WHERE  inschrijving_id = p_inschrijving_id
      AND  status = 'aangevraagd';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Inschrijving % bestaat niet of staat niet op "aangevraagd".',
                        p_inschrijving_id;
    END IF;

    RAISE NOTICE 'Inschrijving % is bevestigd.', p_inschrijving_id;
END;
$$;


ALTER PROCEDURE public.sp_inschrijving_bevestigen(IN p_inschrijving_id integer) OWNER TO postgres;

--
-- Name: sp_lesgever_toevoegen(character varying, character varying, character varying, character varying, character varying, character varying, numeric, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_lesgever_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying DEFAULT NULL::character varying, IN p_publieke_bio character varying DEFAULT NULL::character varying, IN p_ondernemingsnummer character varying DEFAULT NULL::character varying, IN p_uurtarief numeric DEFAULT NULL::numeric, IN p_iban character varying DEFAULT NULL::character varying, IN p_in_dienst_sinds date DEFAULT CURRENT_DATE)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_persoon_id INT;
BEGIN
    SELECT persoon_id
    INTO   v_persoon_id
    FROM   persoon
    WHERE  LOWER(email) = LOWER(p_email);

    IF v_persoon_id IS NULL THEN
        INSERT INTO persoon (voornaam, familienaam, email, telefoon)
        VALUES (TRIM(p_voornaam), TRIM(p_familienaam), p_email, p_telefoon)
        RETURNING persoon_id INTO v_persoon_id;
    END IF;

    IF EXISTS (SELECT 1 FROM lesgever WHERE lesgever_id = v_persoon_id) THEN
        RAISE EXCEPTION 'Deze persoon (%) is al geregistreerd als lesgever.', p_email;
    END IF;

    INSERT INTO lesgever (lesgever_id, lesgevernummer, publieke_bio,
                          ondernemingsnummer, uurtarief, iban, in_dienst_sinds)
    VALUES (v_persoon_id,
            'L' || LPAD(v_persoon_id::TEXT, 4, '0'),
            p_publieke_bio, p_ondernemingsnummer, p_uurtarief, p_iban, p_in_dienst_sinds);

    RAISE NOTICE 'Lesgever % % toegevoegd met nummer L%.',
                 p_voornaam, p_familienaam, LPAD(v_persoon_id::TEXT, 4, '0');
END;
$$;


ALTER PROCEDURE public.sp_lesgever_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_publieke_bio character varying, IN p_ondernemingsnummer character varying, IN p_uurtarief numeric, IN p_iban character varying, IN p_in_dienst_sinds date) OWNER TO postgres;

--
-- Name: sp_lesgever_toewijzen(character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_lesgever_toewijzen(IN p_periode_code character varying, IN p_module_code character varying, IN p_email character varying, IN p_rol character varying DEFAULT 'hoofddocent'::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_pm_id       INT;
    v_lesgever_id INT;
BEGIN
    SELECT pm.periode_module_id
    INTO   v_pm_id
    FROM   periode_module      pm
    JOIN   opleidingsperiode   p ON p.periode_id = pm.periode_id
    JOIN   module              m ON m.module_id  = pm.module_id
    WHERE  p.code = p_periode_code
      AND  m.code = p_module_code;

    IF v_pm_id IS NULL THEN
        RAISE EXCEPTION 'Module "%" is niet ingepland in periode "%".',
                        p_module_code, p_periode_code;
    END IF;

    SELECT l.lesgever_id
    INTO   v_lesgever_id
    FROM   lesgever l
    JOIN   persoon  p ON p.persoon_id = l.lesgever_id
    WHERE  LOWER(p.email) = LOWER(p_email);

    IF v_lesgever_id IS NULL THEN
        RAISE EXCEPTION 'Geen lesgever gevonden met e-mailadres "%".', p_email;
    END IF;

    INSERT INTO periode_module_lesgever (periode_module_id, lesgever_id, rol)
    VALUES (v_pm_id, v_lesgever_id, p_rol)
    ON CONFLICT (periode_module_id, lesgever_id)
    DO UPDATE SET rol = EXCLUDED.rol;

    RAISE NOTICE 'Lesgever % toegewezen aan module % in periode % als %.',
                 p_email, p_module_code, p_periode_code, p_rol;
END;
$$;


ALTER PROCEDURE public.sp_lesgever_toewijzen(IN p_periode_code character varying, IN p_module_code character varying, IN p_email character varying, IN p_rol character varying) OWNER TO postgres;

--
-- Name: sp_module_plannen(character varying, character varying, date, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_module_plannen(IN p_periode_code character varying, IN p_module_code character varying, IN p_startdatum date, IN p_einddatum date)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_periode_id   INT;
    v_opleiding_id INT;
    v_module_id    INT;
BEGIN
    SELECT periode_id, opleiding_id
    INTO   v_periode_id, v_opleiding_id
    FROM   opleidingsperiode
    WHERE  code = p_periode_code;

    IF v_periode_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende opleidingsperiode "%".', p_periode_code;
    END IF;

    SELECT module_id
    INTO   v_module_id
    FROM   module
    WHERE  opleiding_id = v_opleiding_id
      AND  code = p_module_code;

    IF v_module_id IS NULL THEN
        RAISE EXCEPTION 'Module "%" hoort niet bij de opleiding van periode "%".',
                        p_module_code, p_periode_code;
    END IF;

    UPDATE periode_module
    SET    startdatum = p_startdatum,
           einddatum  = p_einddatum
    WHERE  periode_id = v_periode_id
      AND  module_id  = v_module_id;

    -- Stond de module nog niet ingepland? Dan alsnog toevoegen.
    IF NOT FOUND THEN
        INSERT INTO periode_module (periode_id, module_id, volgorde, startdatum, einddatum)
        SELECT v_periode_id, v_module_id, m.volgorde, p_startdatum, p_einddatum
        FROM   module m
        WHERE  m.module_id = v_module_id;
    END IF;

    RAISE NOTICE 'Module % in periode % gepland van % tot %.',
                 p_module_code, p_periode_code, p_startdatum, p_einddatum;
END;
$$;


ALTER PROCEDURE public.sp_module_plannen(IN p_periode_code character varying, IN p_module_code character varying, IN p_startdatum date, IN p_einddatum date) OWNER TO postgres;

--
-- Name: sp_module_toevoegen(character varying, character varying, character varying, character varying, integer, boolean, boolean, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_module_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_naam character varying, IN p_omschrijving character varying DEFAULT NULL::character varying, IN p_aantal_sessies integer DEFAULT NULL::integer, IN p_vrijstelbaar boolean DEFAULT false, IN p_eindproef boolean DEFAULT false, IN p_volgorde integer DEFAULT NULL::integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_opleiding_id INT;
    v_volgorde     INT;
BEGIN
    SELECT opleiding_id
    INTO   v_opleiding_id
    FROM   opleiding
    WHERE  slug = p_opleiding_slug;

    IF v_opleiding_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende opleiding met slug "%".', p_opleiding_slug;
    END IF;

    -- Geen volgorde meegegeven? Dan achteraan toevoegen.
    IF p_volgorde IS NULL THEN
        SELECT COALESCE(MAX(volgorde), 0) + 1
        INTO   v_volgorde
        FROM   module
        WHERE  opleiding_id = v_opleiding_id;
    ELSE
        v_volgorde := p_volgorde;
    END IF;

    INSERT INTO module (opleiding_id, code, naam, omschrijving,
                        aantal_sessies, vrijstelbaar, eindproef, volgorde)
    VALUES (v_opleiding_id, p_code, p_naam, p_omschrijving,
            p_aantal_sessies, p_vrijstelbaar, p_eindproef, v_volgorde);

    RAISE NOTICE 'Module "%" (%) toegevoegd aan "%".', p_naam, p_code, p_opleiding_slug;
END;
$$;


ALTER PROCEDURE public.sp_module_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_naam character varying, IN p_omschrijving character varying, IN p_aantal_sessies integer, IN p_vrijstelbaar boolean, IN p_eindproef boolean, IN p_volgorde integer) OWNER TO postgres;

--
-- Name: sp_opleiding_toevoegen(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, numeric, boolean, boolean); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_opleiding_toevoegen(IN p_subcategorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_vorm_code character varying, IN p_niveau_code character varying DEFAULT 'beginner'::character varying, IN p_korte_omschrijving character varying DEFAULT NULL::character varying, IN p_lange_omschrijving character varying DEFAULT NULL::character varying, IN p_doelgroep character varying DEFAULT NULL::character varying, IN p_duur_in_jaren numeric DEFAULT 1, IN p_ai_geintegreerd boolean DEFAULT false, IN p_nieuw boolean DEFAULT false)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_subcategorie_id INT;
    v_id              INT;
BEGIN
    SELECT subcategorie_id
    INTO   v_subcategorie_id
    FROM   subcategorie
    WHERE  slug = p_subcategorie_slug;

    IF v_subcategorie_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende subcategorie met slug "%".', p_subcategorie_slug;
    END IF;

    INSERT INTO opleiding (subcategorie_id, vorm_code, niveau_code, naam, slug,
                           korte_omschrijving, lange_omschrijving, doelgroep,
                           duur_in_jaren, ai_geintegreerd, nieuw)
    VALUES (v_subcategorie_id, p_vorm_code, p_niveau_code, TRIM(p_naam), p_slug,
            p_korte_omschrijving, p_lange_omschrijving, p_doelgroep,
            p_duur_in_jaren, p_ai_geintegreerd, p_nieuw)
    RETURNING opleiding_id INTO v_id;

    RAISE NOTICE 'Opleiding "%" toegevoegd met id %.', p_naam, v_id;
END;
$$;


ALTER PROCEDURE public.sp_opleiding_toevoegen(IN p_subcategorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_vorm_code character varying, IN p_niveau_code character varying, IN p_korte_omschrijving character varying, IN p_lange_omschrijving character varying, IN p_doelgroep character varying, IN p_duur_in_jaren numeric, IN p_ai_geintegreerd boolean, IN p_nieuw boolean) OWNER TO postgres;

--
-- Name: sp_periode_toevoegen(character varying, character varying, character varying, character varying, date, date, numeric, integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_periode_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_academiejaar character varying, IN p_campus character varying, IN p_startdatum date, IN p_einddatum date, IN p_prijs numeric, IN p_max_cursisten integer DEFAULT 18, IN p_dagdeel character varying DEFAULT 'avond'::character varying, IN p_lessenrooster_url character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_opleiding_id INT;
    v_campus_id    INT;
    v_periode_id   INT;
    v_aantal       INT;
BEGIN
    SELECT opleiding_id INTO v_opleiding_id FROM opleiding WHERE slug = p_opleiding_slug;
    IF v_opleiding_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende opleiding met slug "%".', p_opleiding_slug;
    END IF;

    SELECT campus_id INTO v_campus_id FROM campus WHERE naam = p_campus;
    IF v_campus_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende campus "%".', p_campus;
    END IF;

    INSERT INTO opleidingsperiode (opleiding_id, campus_id, code, academiejaar,
                                   startdatum, einddatum, dagdeel, prijs,
                                   max_cursisten, inschrijven_tot, status,
                                   lessenrooster_url)
    VALUES (v_opleiding_id, v_campus_id, p_code, p_academiejaar,
            p_startdatum, p_einddatum, p_dagdeel, p_prijs,
            p_max_cursisten, p_startdatum - 1, 'open', p_lessenrooster_url)
    RETURNING periode_id INTO v_periode_id;

    -- Alle modules van de opleiding meteen inplannen.
    INSERT INTO periode_module (periode_id, module_id, volgorde, startdatum, einddatum)
    SELECT v_periode_id, m.module_id, m.volgorde, p_startdatum, p_einddatum
    FROM   module m
    WHERE  m.opleiding_id = v_opleiding_id;

    GET DIAGNOSTICS v_aantal = ROW_COUNT;

    RAISE NOTICE 'Periode "%" aangemaakt (id %) met % ingeplande modules.',
                 p_code, v_periode_id, v_aantal;
END;
$$;


ALTER PROCEDURE public.sp_periode_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_academiejaar character varying, IN p_campus character varying, IN p_startdatum date, IN p_einddatum date, IN p_prijs numeric, IN p_max_cursisten integer, IN p_dagdeel character varying, IN p_lessenrooster_url character varying) OWNER TO postgres;

--
-- Name: sp_subcategorie_toevoegen(character varying, character varying, character varying, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_subcategorie_toevoegen(IN p_categorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying DEFAULT NULL::character varying, IN p_afbeelding_url character varying DEFAULT NULL::character varying, IN p_volgorde integer DEFAULT 0)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_categorie_id INT;
    v_id           INT;
BEGIN
    SELECT categorie_id
    INTO   v_categorie_id
    FROM   categorie
    WHERE  slug = p_categorie_slug;

    IF v_categorie_id IS NULL THEN
        RAISE EXCEPTION 'Onbekende categorie met slug "%".', p_categorie_slug;
    END IF;

    INSERT INTO subcategorie (categorie_id, naam, slug, omschrijving, afbeelding_url, volgorde)
    VALUES (v_categorie_id, TRIM(p_naam), p_slug, p_omschrijving, p_afbeelding_url, p_volgorde)
    RETURNING subcategorie_id INTO v_id;

    RAISE NOTICE 'Subcategorie "%" toegevoegd onder "%" met id %.',
                 p_naam, p_categorie_slug, v_id;
END;
$$;


ALTER PROCEDURE public.sp_subcategorie_toevoegen(IN p_categorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) OWNER TO postgres;

--
-- Name: sp_vrijstelling_toekennen(integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_vrijstelling_toekennen(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_motivatie character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_im_id        INT;
    v_vrijstelbaar BOOLEAN;
BEGIN
    SELECT im.inschrijving_module_id, m.vrijstelbaar
    INTO   v_im_id, v_vrijstelbaar
    FROM   inschrijving_module im
    JOIN   periode_module      pm ON pm.periode_module_id = im.periode_module_id
    JOIN   module              m  ON m.module_id = pm.module_id
    WHERE  im.inschrijving_id = p_inschrijving_id
      AND  m.code = p_module_code;

    IF v_im_id IS NULL THEN
        RAISE EXCEPTION 'Module "%" hoort niet bij inschrijving %.',
                        p_module_code, p_inschrijving_id;
    END IF;

    IF NOT v_vrijstelbaar THEN
        RAISE EXCEPTION 'Voor module "%" kan geen vrijstelling toegekend worden.',
                        p_module_code;
    END IF;

    UPDATE inschrijving_module
    SET    vrijstelling           = TRUE,
           vrijstelling_motivatie = p_motivatie
    WHERE  inschrijving_module_id = v_im_id;

    RAISE NOTICE 'Vrijstelling toegekend voor module % bij inschrijving %.',
                 p_module_code, p_inschrijving_id;
END;
$$;


ALTER PROCEDURE public.sp_vrijstelling_toekennen(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_motivatie character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: betaling; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.betaling (
    betaling_id integer NOT NULL,
    inschrijving_id integer NOT NULL,
    bedrag numeric(8,2) NOT NULL,
    betaaldatum date DEFAULT CURRENT_DATE NOT NULL,
    methode character varying(25) NOT NULL,
    referentie character varying(50),
    CONSTRAINT ck_betaling_bedrag CHECK ((bedrag > (0)::numeric)),
    CONSTRAINT ck_betaling_methode CHECK (((methode)::text = ANY ((ARRAY['overschrijving'::character varying, 'bancontact'::character varying, 'kredietkaart'::character varying, 'opleidingscheque'::character varying, 'kmo_portefeuille'::character varying, 'factuur'::character varying])::text[])))
);


ALTER TABLE public.betaling OWNER TO postgres;

--
-- Name: betaling_betaling_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.betaling ALTER COLUMN betaling_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.betaling_betaling_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: campus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campus (
    campus_id integer NOT NULL,
    naam character varying(50) NOT NULL,
    adres character varying(100) NOT NULL,
    postcode character(4) NOT NULL,
    gemeente character varying(50) NOT NULL,
    telefoon character varying(20),
    email character varying(254),
    CONSTRAINT ck_campus_postcode CHECK ((postcode ~ '^[1-9][0-9]{3}$'::text))
);


ALTER TABLE public.campus OWNER TO postgres;

--
-- Name: campus_campus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.campus ALTER COLUMN campus_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.campus_campus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categorie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorie (
    categorie_id integer NOT NULL,
    naam character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    omschrijving character varying(1000),
    afbeelding_url character varying(255),
    volgorde smallint DEFAULT 0 NOT NULL,
    gepubliceerd boolean DEFAULT true NOT NULL,
    aangemaakt_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categorie OWNER TO postgres;

--
-- Name: TABLE categorie; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.categorie IS 'Thema''s zoals op https://syntra-mvl.be/nl/opleidingen';


--
-- Name: COLUMN categorie.slug; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.categorie.slug IS 'Deel van de URL, bv. grafisch-it-en-media';


--
-- Name: categorie_categorie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.categorie ALTER COLUMN categorie_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.categorie_categorie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cursist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cursist (
    cursist_id integer NOT NULL,
    cursistnummer character varying(15) NOT NULL,
    wachtwoord_hash character varying(100),
    dossier_sinds date DEFAULT CURRENT_DATE NOT NULL,
    hoogste_diploma character varying(100),
    opleidingscheques boolean DEFAULT false NOT NULL,
    kmo_portefeuille boolean DEFAULT false NOT NULL,
    interne_notitie character varying(1000),
    actief boolean DEFAULT true NOT NULL
);


ALTER TABLE public.cursist OWNER TO postgres;

--
-- Name: COLUMN cursist.wachtwoord_hash; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cursist.wachtwoord_hash IS 'Versleuteld met pgcrypto crypt(). Nooit het wachtwoord zelf bewaren.';


--
-- Name: COLUMN cursist.interne_notitie; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.cursist.interne_notitie IS 'Notities van de administratie - strikt intern.';


--
-- Name: evaluatie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evaluatie (
    evaluatie_id integer NOT NULL,
    inschrijving_module_id integer NOT NULL,
    evaluatiedatum date DEFAULT CURRENT_DATE NOT NULL,
    score numeric(5,2) NOT NULL,
    poging smallint DEFAULT 1 NOT NULL,
    feedback character varying(500),
    lesgever_id integer,
    CONSTRAINT ck_evaluatie_poging CHECK (((poging >= 1) AND (poging <= 3))),
    CONSTRAINT ck_evaluatie_score CHECK (((score >= (0)::numeric) AND (score <= (100)::numeric)))
);


ALTER TABLE public.evaluatie OWNER TO postgres;

--
-- Name: evaluatie_evaluatie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.evaluatie ALTER COLUMN evaluatie_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.evaluatie_evaluatie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inschrijving; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inschrijving (
    inschrijving_id integer NOT NULL,
    cursist_id integer NOT NULL,
    periode_id integer NOT NULL,
    status character varying(15) DEFAULT 'aangevraagd'::character varying NOT NULL,
    ingeschreven_op timestamp without time zone DEFAULT now() NOT NULL,
    te_betalen numeric(8,2) NOT NULL,
    korting character varying(100),
    opmerking character varying(500),
    CONSTRAINT ck_inschrijving_bedrag CHECK ((te_betalen >= (0)::numeric)),
    CONSTRAINT ck_inschrijving_status CHECK (((status)::text = ANY ((ARRAY['aangevraagd'::character varying, 'bevestigd'::character varying, 'geannuleerd'::character varying, 'afgewerkt'::character varying])::text[])))
);


ALTER TABLE public.inschrijving OWNER TO postgres;

--
-- Name: inschrijving_inschrijving_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.inschrijving ALTER COLUMN inschrijving_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inschrijving_inschrijving_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inschrijving_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inschrijving_log (
    log_id integer NOT NULL,
    inschrijving_id integer NOT NULL,
    oude_status character varying(15),
    nieuwe_status character varying(15) NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_door character varying(63) DEFAULT CURRENT_USER NOT NULL
);


ALTER TABLE public.inschrijving_log OWNER TO postgres;

--
-- Name: inschrijving_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.inschrijving_log ALTER COLUMN log_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inschrijving_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inschrijving_module; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inschrijving_module (
    inschrijving_module_id integer NOT NULL,
    inschrijving_id integer NOT NULL,
    periode_module_id integer NOT NULL,
    vrijstelling boolean DEFAULT false NOT NULL,
    vrijstelling_motivatie character varying(500)
);


ALTER TABLE public.inschrijving_module OWNER TO postgres;

--
-- Name: inschrijving_module_inschrijving_module_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.inschrijving_module ALTER COLUMN inschrijving_module_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inschrijving_module_inschrijving_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: lesgever; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesgever (
    lesgever_id integer NOT NULL,
    lesgevernummer character varying(15) NOT NULL,
    publieke_bio character varying(1000),
    foto_url character varying(255),
    linkedin_url character varying(255),
    zichtbaar_op_web boolean DEFAULT true NOT NULL,
    ondernemingsnummer character varying(15),
    uurtarief numeric(6,2),
    iban character varying(34),
    in_dienst_sinds date,
    uit_dienst_op date,
    CONSTRAINT ck_lesgever_dienst CHECK (((uit_dienst_op IS NULL) OR (in_dienst_sinds IS NULL) OR (uit_dienst_op >= in_dienst_sinds))),
    CONSTRAINT ck_lesgever_tarief CHECK (((uurtarief IS NULL) OR (uurtarief >= (0)::numeric)))
);


ALTER TABLE public.lesgever OWNER TO postgres;

--
-- Name: module; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.module (
    module_id integer NOT NULL,
    opleiding_id integer NOT NULL,
    code character varying(20) NOT NULL,
    naam character varying(150) NOT NULL,
    omschrijving character varying(1000),
    aantal_sessies smallint,
    vrijstelbaar boolean DEFAULT false NOT NULL,
    eindproef boolean DEFAULT false NOT NULL,
    volgorde smallint DEFAULT 0 NOT NULL,
    CONSTRAINT ck_module_sessies CHECK (((aantal_sessies IS NULL) OR (aantal_sessies > 0)))
);


ALTER TABLE public.module OWNER TO postgres;

--
-- Name: module_module_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.module ALTER COLUMN module_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.module_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: niveau; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.niveau (
    niveau_code character varying(20) NOT NULL,
    omschrijving character varying(50) NOT NULL,
    volgorde smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.niveau OWNER TO postgres;

--
-- Name: opleiding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opleiding (
    opleiding_id integer NOT NULL,
    subcategorie_id integer NOT NULL,
    vorm_code character varying(20) NOT NULL,
    niveau_code character varying(20) NOT NULL,
    naam character varying(150) NOT NULL,
    slug character varying(150) NOT NULL,
    korte_omschrijving character varying(500),
    lange_omschrijving character varying(2000),
    doelgroep character varying(1000),
    duur_in_jaren numeric(3,1),
    ai_geintegreerd boolean DEFAULT false NOT NULL,
    nieuw boolean DEFAULT false NOT NULL,
    gepubliceerd boolean DEFAULT true NOT NULL,
    aangemaakt_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_opleiding_duur CHECK (((duur_in_jaren IS NULL) OR (duur_in_jaren > (0)::numeric)))
);


ALTER TABLE public.opleiding OWNER TO postgres;

--
-- Name: opleiding_opleiding_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.opleiding ALTER COLUMN opleiding_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.opleiding_opleiding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: opleidingsperiode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opleidingsperiode (
    periode_id integer NOT NULL,
    opleiding_id integer NOT NULL,
    campus_id integer NOT NULL,
    code character varying(30) NOT NULL,
    academiejaar character(9) NOT NULL,
    startdatum date NOT NULL,
    einddatum date NOT NULL,
    dagdeel character varying(10) DEFAULT 'avond'::character varying NOT NULL,
    prijs numeric(8,2) NOT NULL,
    max_cursisten smallint NOT NULL,
    inschrijven_tot date,
    status character varying(15) DEFAULT 'gepland'::character varying NOT NULL,
    lessenrooster_url character varying(255),
    aangemaakt_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_periode_dagdeel CHECK (((dagdeel)::text = ANY ((ARRAY['dag'::character varying, 'avond'::character varying, 'weekend'::character varying, 'online'::character varying])::text[]))),
    CONSTRAINT ck_periode_datums CHECK ((einddatum > startdatum)),
    CONSTRAINT ck_periode_jaar CHECK ((academiejaar ~ '^[0-9]{4}-[0-9]{4}$'::text)),
    CONSTRAINT ck_periode_max CHECK ((max_cursisten > 0)),
    CONSTRAINT ck_periode_prijs CHECK ((prijs >= (0)::numeric)),
    CONSTRAINT ck_periode_status CHECK (((status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying, 'volzet'::character varying, 'gestart'::character varying, 'afgelopen'::character varying, 'geannuleerd'::character varying])::text[])))
);


ALTER TABLE public.opleidingsperiode OWNER TO postgres;

--
-- Name: opleidingsperiode_periode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.opleidingsperiode ALTER COLUMN periode_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.opleidingsperiode_periode_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: opleidingsvorm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opleidingsvorm (
    vorm_code character varying(20) NOT NULL,
    omschrijving character varying(50) NOT NULL,
    volgorde smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.opleidingsvorm OWNER TO postgres;

--
-- Name: periode_module; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periode_module (
    periode_module_id integer NOT NULL,
    periode_id integer NOT NULL,
    module_id integer NOT NULL,
    volgorde smallint DEFAULT 0 NOT NULL,
    startdatum date NOT NULL,
    einddatum date NOT NULL,
    CONSTRAINT ck_periode_module_datums CHECK ((einddatum >= startdatum))
);


ALTER TABLE public.periode_module OWNER TO postgres;

--
-- Name: periode_module_lesgever; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periode_module_lesgever (
    periode_module_id integer NOT NULL,
    lesgever_id integer NOT NULL,
    rol character varying(15) DEFAULT 'hoofddocent'::character varying NOT NULL,
    toegewezen_op timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_pml_rol CHECK (((rol)::text = ANY ((ARRAY['hoofddocent'::character varying, 'co-docent'::character varying, 'gastdocent'::character varying])::text[])))
);


ALTER TABLE public.periode_module_lesgever OWNER TO postgres;

--
-- Name: periode_module_periode_module_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.periode_module ALTER COLUMN periode_module_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.periode_module_periode_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: persoon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persoon (
    persoon_id integer NOT NULL,
    voornaam character varying(50) NOT NULL,
    familienaam character varying(100) NOT NULL,
    email character varying(254) NOT NULL,
    telefoon character varying(20),
    rijksregisternr character(11),
    geboortedatum date,
    adres character varying(100),
    postcode character varying(10),
    gemeente character varying(50),
    land character(2) DEFAULT 'BE'::bpchar NOT NULL,
    aangemaakt_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_persoon_email CHECK (((email)::text ~~ '%_@_%._%'::text)),
    CONSTRAINT ck_persoon_gebdat CHECK (((geboortedatum IS NULL) OR (geboortedatum < CURRENT_DATE))),
    CONSTRAINT ck_persoon_rrn CHECK (((rijksregisternr IS NULL) OR (rijksregisternr ~ '^[0-9]{11}$'::text)))
);


ALTER TABLE public.persoon OWNER TO postgres;

--
-- Name: TABLE persoon; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.persoon IS 'Persoonsgegevens - AFGESCHERMD, nooit rechtstreeks naar de website.';


--
-- Name: COLUMN persoon.rijksregisternr; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.persoon.rijksregisternr IS 'Gevoelig gegeven: enkel zichtbaar voor de rol syntra_admin.';


--
-- Name: persoon_persoon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.persoon ALTER COLUMN persoon_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.persoon_persoon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subcategorie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcategorie (
    subcategorie_id integer NOT NULL,
    categorie_id integer NOT NULL,
    naam character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    omschrijving character varying(1000),
    afbeelding_url character varying(255),
    volgorde smallint DEFAULT 0 NOT NULL,
    gepubliceerd boolean DEFAULT true NOT NULL,
    aangemaakt_op timestamp without time zone DEFAULT now() NOT NULL,
    gewijzigd_op timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subcategorie OWNER TO postgres;

--
-- Name: subcategorie_subcategorie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.subcategorie ALTER COLUMN subcategorie_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subcategorie_subcategorie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vw_int_bezetting; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_bezetting AS
 SELECT p.periode_id,
    p.code AS periode_code,
    o.naam AS opleiding,
    p.academiejaar,
    ca.naam AS campus,
    p.startdatum,
    p.status,
    p.max_cursisten,
    public.fn_aantal_ingeschreven(p.periode_id) AS ingeschreven,
    public.fn_vrije_plaatsen(p.periode_id) AS vrije_plaatsen,
    round(((100.0 * (public.fn_aantal_ingeschreven(p.periode_id))::numeric) / (p.max_cursisten)::numeric), 1) AS bezetting_pct,
    ( SELECT count(*) AS count
           FROM public.periode_module pm
          WHERE (pm.periode_id = p.periode_id)) AS aantal_modules,
    ( SELECT COALESCE(sum(i.te_betalen), (0)::numeric) AS "coalesce"
           FROM public.inschrijving i
          WHERE ((i.periode_id = p.periode_id) AND ((i.status)::text <> 'geannuleerd'::text))) AS verwachte_omzet
   FROM ((public.opleidingsperiode p
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
     JOIN public.campus ca ON ((ca.campus_id = p.campus_id)))
  ORDER BY p.startdatum;


ALTER VIEW public.vw_int_bezetting OWNER TO postgres;

--
-- Name: vw_int_cursist; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_cursist AS
 SELECT c.cursist_id,
    c.cursistnummer,
    p.voornaam,
    p.familienaam,
    p.email,
    p.telefoon,
    p.geboortedatum,
    public.fn_leeftijd(p.geboortedatum) AS leeftijd,
    p.adres,
    p.postcode,
    p.gemeente,
    c.hoogste_diploma,
    c.opleidingscheques,
    c.kmo_portefeuille,
    c.actief,
    c.dossier_sinds,
    ( SELECT count(*) AS count
           FROM public.inschrijving i
          WHERE (i.cursist_id = c.cursist_id)) AS aantal_inschrijvingen
   FROM (public.cursist c
     JOIN public.persoon p ON ((p.persoon_id = c.cursist_id)))
  ORDER BY p.familienaam, p.voornaam;


ALTER VIEW public.vw_int_cursist OWNER TO postgres;

--
-- Name: vw_int_klaslijst; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_klaslijst AS
 SELECT p.periode_id,
    p.code AS periode_code,
    o.naam AS opleiding,
    p.startdatum,
    c.cursistnummer,
    per.voornaam,
    per.familienaam,
    per.email,
    per.telefoon,
    i.inschrijving_id,
    i.status,
    (i.ingeschreven_op)::date AS ingeschreven_op,
    i.te_betalen,
    public.fn_openstaand_saldo(i.inschrijving_id) AS openstaand
   FROM ((((public.inschrijving i
     JOIN public.cursist c ON ((c.cursist_id = i.cursist_id)))
     JOIN public.persoon per ON ((per.persoon_id = c.cursist_id)))
     JOIN public.opleidingsperiode p ON ((p.periode_id = i.periode_id)))
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
  ORDER BY p.startdatum, o.naam, per.familienaam, per.voornaam;


ALTER VIEW public.vw_int_klaslijst OWNER TO postgres;

--
-- Name: vw_int_lesgever; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_lesgever AS
 SELECT l.lesgever_id,
    l.lesgevernummer,
    p.voornaam,
    p.familienaam,
    p.email,
    p.telefoon,
    l.ondernemingsnummer,
    l.uurtarief,
    l.iban,
    l.in_dienst_sinds,
    l.uit_dienst_op,
    l.zichtbaar_op_web
   FROM (public.lesgever l
     JOIN public.persoon p ON ((p.persoon_id = l.lesgever_id)))
  ORDER BY p.familienaam, p.voornaam;


ALTER VIEW public.vw_int_lesgever OWNER TO postgres;

--
-- Name: vw_int_lesopdracht; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_lesopdracht AS
 SELECT l.lesgever_id,
    (((per.voornaam)::text || ' '::text) || (per.familienaam)::text) AS lesgever,
    per.email,
    o.naam AS opleiding,
    p.code AS periode_code,
    p.academiejaar,
    m.code AS module_code,
    m.naam AS module,
    m.aantal_sessies,
    pml.rol,
    pm.startdatum,
    pm.einddatum,
    ca.naam AS campus,
    ( SELECT count(*) AS count
           FROM (public.inschrijving_module im
             JOIN public.inschrijving i ON ((i.inschrijving_id = im.inschrijving_id)))
          WHERE ((im.periode_module_id = pm.periode_module_id) AND ((i.status)::text = ANY ((ARRAY['aangevraagd'::character varying, 'bevestigd'::character varying, 'afgewerkt'::character varying])::text[])))) AS aantal_cursisten
   FROM (((((((public.periode_module_lesgever pml
     JOIN public.periode_module pm ON ((pm.periode_module_id = pml.periode_module_id)))
     JOIN public.module m ON ((m.module_id = pm.module_id)))
     JOIN public.opleidingsperiode p ON ((p.periode_id = pm.periode_id)))
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
     JOIN public.campus ca ON ((ca.campus_id = p.campus_id)))
     JOIN public.lesgever l ON ((l.lesgever_id = pml.lesgever_id)))
     JOIN public.persoon per ON ((per.persoon_id = l.lesgever_id)))
  ORDER BY p.startdatum, m.volgorde, per.familienaam;


ALTER VIEW public.vw_int_lesopdracht OWNER TO postgres;

--
-- Name: vw_int_openstaand; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_openstaand AS
 SELECT i.inschrijving_id,
    c.cursistnummer,
    (((per.voornaam)::text || ' '::text) || (per.familienaam)::text) AS cursist,
    per.email,
    o.naam AS opleiding,
    p.code AS periode_code,
    i.te_betalen,
    COALESCE(sum(b.bedrag), (0)::numeric) AS betaald,
    (i.te_betalen - COALESCE(sum(b.bedrag), (0)::numeric)) AS openstaand,
    max(b.betaaldatum) AS laatste_betaling
   FROM (((((public.inschrijving i
     JOIN public.cursist c ON ((c.cursist_id = i.cursist_id)))
     JOIN public.persoon per ON ((per.persoon_id = c.cursist_id)))
     JOIN public.opleidingsperiode p ON ((p.periode_id = i.periode_id)))
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
     LEFT JOIN public.betaling b ON ((b.inschrijving_id = i.inschrijving_id)))
  WHERE ((i.status)::text <> 'geannuleerd'::text)
  GROUP BY i.inschrijving_id, c.cursistnummer, per.voornaam, per.familienaam, per.email, o.naam, p.code, i.te_betalen
 HAVING ((i.te_betalen - COALESCE(sum(b.bedrag), (0)::numeric)) > (0)::numeric)
  ORDER BY (i.te_betalen - COALESCE(sum(b.bedrag), (0)::numeric)) DESC;


ALTER VIEW public.vw_int_openstaand OWNER TO postgres;

--
-- Name: vw_int_resultaat; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_int_resultaat AS
 SELECT i.inschrijving_id,
    p.periode_id,
    p.code AS periode_code,
    o.naam AS opleiding,
    c.cursistnummer,
    (((per.familienaam)::text || ' '::text) || (per.voornaam)::text) AS cursist,
    m.code AS module_code,
    m.naam AS module,
    im.inschrijving_module_id,
    im.vrijstelling,
    e.poging,
    e.score,
        CASE
            WHEN (e.score IS NULL) THEN NULL::boolean
            WHEN (e.score >= (50)::numeric) THEN true
            ELSE false
        END AS geslaagd,
    e.evaluatiedatum,
    public.fn_module_geslaagd(im.inschrijving_module_id) AS module_afgerond
   FROM ((((((((public.inschrijving_module im
     JOIN public.inschrijving i ON ((i.inschrijving_id = im.inschrijving_id)))
     JOIN public.cursist c ON ((c.cursist_id = i.cursist_id)))
     JOIN public.persoon per ON ((per.persoon_id = c.cursist_id)))
     JOIN public.periode_module pm ON ((pm.periode_module_id = im.periode_module_id)))
     JOIN public.module m ON ((m.module_id = pm.module_id)))
     JOIN public.opleidingsperiode p ON ((p.periode_id = pm.periode_id)))
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
     LEFT JOIN public.evaluatie e ON ((e.inschrijving_module_id = im.inschrijving_module_id)))
  ORDER BY o.naam, per.familienaam, m.volgorde, e.poging;


ALTER VIEW public.vw_int_resultaat OWNER TO postgres;

--
-- Name: vw_pub_categorie; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_categorie AS
 SELECT c.categorie_id,
    c.naam,
    c.slug,
    c.omschrijving,
    c.afbeelding_url,
    ('/nl/opleidingen/'::text || (c.slug)::text) AS url,
    count(DISTINCT s.subcategorie_id) AS aantal_subcategorieen,
    count(DISTINCT o.opleiding_id) AS aantal_opleidingen,
    c.volgorde
   FROM ((public.categorie c
     LEFT JOIN public.subcategorie s ON (((s.categorie_id = c.categorie_id) AND s.gepubliceerd)))
     LEFT JOIN public.opleiding o ON (((o.subcategorie_id = s.subcategorie_id) AND o.gepubliceerd)))
  WHERE c.gepubliceerd
  GROUP BY c.categorie_id, c.naam, c.slug, c.omschrijving, c.afbeelding_url, c.volgorde
  ORDER BY c.volgorde, c.naam;


ALTER VIEW public.vw_pub_categorie OWNER TO postgres;

--
-- Name: VIEW vw_pub_categorie; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.vw_pub_categorie IS 'Themakaarten op de overzichtspagina van alle opleidingen.';


--
-- Name: vw_pub_lesgever; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_lesgever AS
 SELECT l.lesgever_id,
    p.voornaam,
    (((p.voornaam)::text || ' '::text) || (p.familienaam)::text) AS naam,
    l.publieke_bio,
    l.foto_url,
    l.linkedin_url
   FROM (public.lesgever l
     JOIN public.persoon p ON ((p.persoon_id = l.lesgever_id)))
  WHERE (l.zichtbaar_op_web AND (l.uit_dienst_op IS NULL))
  ORDER BY p.familienaam, p.voornaam;


ALTER VIEW public.vw_pub_lesgever OWNER TO postgres;

--
-- Name: vw_pub_opleiding; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_opleiding AS
 SELECT o.opleiding_id,
    o.naam,
    o.slug,
    o.korte_omschrijving,
    c.naam AS categorie,
    c.slug AS categorie_slug,
    s.naam AS subcategorie,
    s.slug AS subcategorie_slug,
    v.omschrijving AS opleidingsvorm,
    n.omschrijving AS niveau,
    o.ai_geintegreerd,
    o.nieuw,
    o.duur_in_jaren,
    ((((('/nl/opleidingen/'::text || (c.slug)::text) || '/'::text) || (s.slug)::text) || '/'::text) || (o.slug)::text) AS url,
    ( SELECT min(p.startdatum) AS min
           FROM public.opleidingsperiode p
          WHERE ((p.opleiding_id = o.opleiding_id) AND ((p.status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying])::text[])) AND (p.startdatum >= CURRENT_DATE))) AS eerstvolgende_start,
    ( SELECT min(p.prijs) AS min
           FROM public.opleidingsperiode p
          WHERE ((p.opleiding_id = o.opleiding_id) AND ((p.status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying])::text[])) AND (p.startdatum >= CURRENT_DATE))) AS prijs_vanaf,
    ( SELECT string_agg(DISTINCT (ca.gemeente)::text, ', '::text) AS string_agg
           FROM (public.opleidingsperiode p
             JOIN public.campus ca ON ((ca.campus_id = p.campus_id)))
          WHERE ((p.opleiding_id = o.opleiding_id) AND ((p.status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying])::text[])) AND (p.startdatum >= CURRENT_DATE))) AS locaties
   FROM ((((public.opleiding o
     JOIN public.subcategorie s ON ((s.subcategorie_id = o.subcategorie_id)))
     JOIN public.categorie c ON ((c.categorie_id = s.categorie_id)))
     JOIN public.opleidingsvorm v ON (((v.vorm_code)::text = (o.vorm_code)::text)))
     JOIN public.niveau n ON (((n.niveau_code)::text = (o.niveau_code)::text)))
  WHERE o.gepubliceerd
  ORDER BY c.volgorde, s.volgorde, o.naam;


ALTER VIEW public.vw_pub_opleiding OWNER TO postgres;

--
-- Name: vw_pub_programma; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_programma AS
 SELECT o.opleiding_id,
    o.slug AS opleiding_slug,
    o.naam AS opleiding,
    m.module_id,
    m.code AS module_code,
    m.naam AS module,
    m.omschrijving,
    m.aantal_sessies,
    m.vrijstelbaar,
    m.eindproef,
    m.volgorde
   FROM (public.module m
     JOIN public.opleiding o ON ((o.opleiding_id = m.opleiding_id)))
  WHERE o.gepubliceerd
  ORDER BY o.naam, m.volgorde;


ALTER VIEW public.vw_pub_programma OWNER TO postgres;

--
-- Name: vw_pub_startmoment; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_startmoment AS
 SELECT p.periode_id,
    o.opleiding_id,
    o.naam AS opleiding,
    o.slug AS opleiding_slug,
    p.code AS periode_code,
    p.academiejaar,
    ca.naam AS campus,
    (((((ca.adres)::text || ', '::text) || (ca.postcode)::text) || ' '::text) || (ca.gemeente)::text) AS adres,
    p.startdatum,
    p.einddatum,
    p.dagdeel,
    p.prijs,
    p.status,
    public.fn_vrije_plaatsen(p.periode_id) AS vrije_plaatsen,
        CASE
            WHEN (((p.status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying])::text[])) AND (public.fn_vrije_plaatsen(p.periode_id) > 0) AND (CURRENT_DATE <= COALESCE(p.inschrijven_tot, p.startdatum))) THEN true
            ELSE false
        END AS inschrijven_mogelijk,
    p.lessenrooster_url
   FROM ((public.opleidingsperiode p
     JOIN public.opleiding o ON ((o.opleiding_id = p.opleiding_id)))
     JOIN public.campus ca ON ((ca.campus_id = p.campus_id)))
  WHERE (o.gepubliceerd AND ((p.status)::text <> 'geannuleerd'::text))
  ORDER BY o.naam, p.startdatum;


ALTER VIEW public.vw_pub_startmoment OWNER TO postgres;

--
-- Name: vw_pub_subcategorie; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_pub_subcategorie AS
 SELECT s.subcategorie_id,
    s.categorie_id,
    c.naam AS categorie,
    c.slug AS categorie_slug,
    s.naam,
    s.slug,
    s.omschrijving,
    s.afbeelding_url,
    ((('/nl/opleidingen/'::text || (c.slug)::text) || '/'::text) || (s.slug)::text) AS url,
    count(o.opleiding_id) AS aantal_opleidingen,
    s.volgorde
   FROM ((public.subcategorie s
     JOIN public.categorie c ON ((c.categorie_id = s.categorie_id)))
     LEFT JOIN public.opleiding o ON (((o.subcategorie_id = s.subcategorie_id) AND o.gepubliceerd)))
  WHERE (s.gepubliceerd AND c.gepubliceerd)
  GROUP BY s.subcategorie_id, s.categorie_id, c.naam, c.slug, c.volgorde, s.naam, s.slug, s.omschrijving, s.afbeelding_url, s.volgorde
  ORDER BY c.volgorde, s.volgorde, s.naam;


ALTER VIEW public.vw_pub_subcategorie OWNER TO postgres;

--
-- Data for Name: betaling; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.betaling (betaling_id, inschrijving_id, bedrag, betaaldatum, methode, referentie) FROM stdin;
1	3	1010.00	2026-09-01	overschrijving	OVS-2026-0007
2	4	336.67	2026-08-28	kredietkaart	KK-2026-0006
3	5	1010.00	2026-08-27	overschrijving	OVS-2026-0005
4	6	500.00	2026-08-26	opleidingscheque	OPL-2026-0004
5	7	1010.00	2026-08-25	bancontact	BC-2026-0003
6	8	1010.00	2026-08-22	kmo_portefeuille	KMO-2026-0002
7	9	1010.00	2026-08-20	overschrijving	OVS-2026-0001
8	12	522.50	2027-08-18	overschrijving	OVS-2027-0008
\.


--
-- Data for Name: campus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campus (campus_id, naam, adres, postcode, gemeente, telefoon, email) FROM stdin;
1	Campus Gent	Autoweg-Zuid 3	9051	Gent	+32 9 265 15 00	gent@syntra-mvl.be
2	Campus Sint-Niklaas	Hogekouter 1	9100	Sint-Niklaas	+32 3 780 55 00	sintniklaas@syntra-mvl.be
3	Campus Aalst	Wijngaardveld 10	9300	Aalst	+32 53 76 91 00	aalst@syntra-mvl.be
\.


--
-- Data for Name: categorie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorie (categorie_id, naam, slug, omschrijving, afbeelding_url, volgorde, gepubliceerd, aangemaakt_op, gewijzigd_op) FROM stdin;
1	Ambachten & interieur	ambachten-interieur	\N	\N	1	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
2	Beauty & Wellness	beauty-wellness	\N	\N	2	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
3	Bouw en energie	bouw-en-energie	\N	\N	3	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
4	Dieren	dieren	\N	\N	4	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
5	Financien, verzekeringen en vastgoed	financien-verzekeringen-en-vastgoed	\N	\N	5	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
6	Grafisch, IT en media	grafisch-it-en-media	Volledig mee zijn in de laatste digitale trends? Dan is een opleiding in IT, media of graphic design jouw volgende stop.	https://syntra-mvl.be/wp-content/uploads/2024/09/SyntraMVL_website_sectorbeelden_400x245_GrafischeMedia.jpg	6	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
7	Groen & tuin	groen-tuin	\N	\N	7	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
8	Horeca, dranken en voeding	horeca-dranken-en-voeding	\N	\N	8	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
9	HR, management en ontwikkeling	hr-management-en-ontwikkeling	\N	\N	9	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
10	Marketing en sales	marketing-en-sales	\N	\N	10	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
11	Microsoft Office	microsoft-office	\N	\N	11	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
12	Ondernemerschap	ondernemerschap	\N	\N	12	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
13	Sport en zorg	sport-en-zorg	\N	\N	13	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
14	Transport & logistiek	transport-logistiek	\N	\N	14	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
15	Veiligheid & preventie	veiligheid-preventie	\N	\N	15	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
16	Voertuigen & metaal	voertuigen-metaal	\N	\N	16	t	2026-08-24 17:42:12.509222	2026-08-24 17:42:12.509222
\.


--
-- Data for Name: cursist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cursist (cursist_id, cursistnummer, wachtwoord_hash, dossier_sinds, hoogste_diploma, opleidingscheques, kmo_portefeuille, interne_notitie, actief) FROM stdin;
6	C00006	$2a$06$c/XAZz.rBLxX4ZDGHsvSEOiuK7gn/0Gew7koyqicq5eStv/EaXySG	2026-08-24	Bachelor communicatiewetenschappen	t	f	\N	t
7	C00007	$2a$06$2.L3OyYVpxH523MID1sp5u5V/b0wue6n7k43XHnnvWBqj81HvApVS	2026-08-24	Bachelor bedrijfsmanagement	f	t	Zelfstandige - factuur op ondernemingsnummer.	t
8	C00008	$2a$06$dHjabBg5uAVIAXIdrkl6suf4sX0vK7H/mVJtDDX6OKvMX.l6/eqsS	2026-08-24	Master biomedische wetenschappen	f	f	\N	t
9	C00009	$2a$06$AMZ6jqs5kVlOotG9Z90rquw2gAz9dN8QPZpda/IZrdyMiuZqtAoQa	2026-08-24	Secundair onderwijs	t	f	\N	t
10	C00010	$2a$06$mzX1ruEQb1Vgl.2dairUZ.O29sjpQBu4fZ9esFyuJLCSpp2ffbSRm	2026-08-24	Bachelor toegepaste informatica	f	f	\N	t
11	C00011	$2a$06$8I8RO9T05HQFDxREsi9Q2.QS9wdHR337RGYixRxxKCCrCM0W..kVa	2026-08-24	Bachelor elektromechanica	f	f	\N	t
12	C00012	$2a$06$eBWaHAe.UYiaoSM3Tfm55.oRRsDXXSMuDwv156BN11bZ7lXIBgbE2	2026-08-24	Bachelor handelswetenschappen	f	f	\N	t
13	C00013	$2a$06$o969ecWNGzfyde5mAaeuCuz45NMBBrLxFgBqKWOmDKcp/lRrX1ESy	2026-08-24	Bachelor accountancy	f	f	\N	t
14	C00014	$2a$06$g1TdJ/iULd6HVOlYpSMFNuThDqiwnplLeflhaBdBVuzP8PhxLmO4e	2026-08-24	Bachelor grafische vormgeving	f	f	\N	t
15	C00015	$2a$06$GzXlRj9yjTGWLPdAPaiEAuU7tPPknKfCxk9REPRfwLRpMdO2pLNpW	2026-08-24	Secundair onderwijs	f	f	\N	t
16	C00016	$2a$06$eJvpROJPetaR/wa3sQmC2ekcFC90WV3DOz97Pgqhrq7B9D17SHMVe	2026-08-24	Master kunstwetenschappen	f	f	\N	t
17	C00017	$2a$06$4KpaIsnKybynU3H.JiSL1OAE1ExeODoFsJg6JmzD38yrlAlmbVMAO	2026-08-24	Bachelor logistiek	f	f	\N	t
\.


--
-- Data for Name: evaluatie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.evaluatie (evaluatie_id, inschrijving_module_id, evaluatiedatum, score, poging, feedback, lesgever_id) FROM stdin;
1	16	2026-11-16	55.00	1	\N	1
2	15	2026-11-16	83.00	1	\N	1
3	14	2026-11-16	70.00	1	\N	1
4	12	2026-12-14	62.00	2	Geslaagd na herkansing.	1
5	12	2026-11-16	44.00	1	Onvoldoende - herkansing nodig.	1
6	11	2026-11-16	91.00	1	Uitstekend.	1
7	10	2026-11-16	65.00	1	Goede basis, oefen nog op loops.	1
8	9	2026-11-16	78.00	1	Sterk logisch inzicht.	1
9	32	2027-03-09	66.00	1	\N	2
10	29	2027-03-09	74.00	1	\N	2
11	27	2027-03-09	88.00	1	Correcte normalisatie.	2
\.


--
-- Data for Name: inschrijving; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inschrijving (inschrijving_id, cursist_id, periode_id, status, ingeschreven_op, te_betalen, korting, opmerking) FROM stdin;
1	14	1	geannuleerd	2026-08-24 17:42:12.568416	1010.00	\N	Cursist heeft afgezegd wegens verhuis.
2	13	1	aangevraagd	2026-08-24 17:42:12.568416	1010.00	\N	Wacht op goedkeuring werkgever
3	12	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
4	11	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
5	10	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
6	9	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
7	8	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
8	7	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
9	6	1	bevestigd	2026-08-24 17:42:12.568416	1010.00	\N	\N
10	17	2	bevestigd	2026-08-24 17:42:12.568416	1045.00	\N	Wenst gespreide betaling
11	16	2	aangevraagd	2026-08-24 17:42:12.568416	945.00	Kortingsactie infoavond	\N
12	15	2	bevestigd	2026-08-24 17:42:12.568416	1045.00	\N	\N
13	12	3	bevestigd	2026-08-24 17:42:12.568416	1150.00	\N	\N
14	11	3	aangevraagd	2026-08-24 17:42:12.568416	1150.00	\N	\N
\.


--
-- Data for Name: inschrijving_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inschrijving_log (log_id, inschrijving_id, oude_status, nieuwe_status, gewijzigd_op, gewijzigd_door) FROM stdin;
1	1	\N	geannuleerd	2026-08-24 17:42:12.568416	postgres
2	2	\N	aangevraagd	2026-08-24 17:42:12.568416	postgres
3	3	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
4	4	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
5	5	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
6	6	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
7	7	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
8	8	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
9	9	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
10	10	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
11	11	\N	aangevraagd	2026-08-24 17:42:12.568416	postgres
12	12	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
13	13	\N	bevestigd	2026-08-24 17:42:12.568416	postgres
14	14	\N	aangevraagd	2026-08-24 17:42:12.568416	postgres
\.


--
-- Data for Name: inschrijving_module; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inschrijving_module (inschrijving_module_id, inschrijving_id, periode_module_id, vrijstelling, vrijstelling_motivatie) FROM stdin;
1	14	15	f	\N
2	13	15	f	\N
3	14	16	f	\N
4	13	16	f	\N
5	14	17	f	\N
6	13	17	f	\N
7	14	18	f	\N
8	13	18	f	\N
9	9	7	f	\N
10	8	7	f	\N
11	7	7	f	\N
12	6	7	f	\N
14	4	7	f	\N
15	3	7	f	\N
16	2	7	f	\N
17	1	7	f	\N
18	9	6	f	\N
19	8	6	f	\N
20	7	6	f	\N
21	6	6	f	\N
23	4	6	f	\N
24	3	6	f	\N
25	2	6	f	\N
26	1	6	f	\N
27	9	5	f	\N
29	7	5	f	\N
30	6	5	f	\N
31	5	5	f	\N
32	4	5	f	\N
33	3	5	f	\N
34	2	5	f	\N
35	1	5	f	\N
36	9	4	f	\N
37	8	4	f	\N
38	7	4	f	\N
39	6	4	f	\N
40	5	4	f	\N
41	4	4	f	\N
42	3	4	f	\N
43	2	4	f	\N
44	1	4	f	\N
45	9	3	f	\N
46	8	3	f	\N
47	7	3	f	\N
48	6	3	f	\N
49	5	3	f	\N
50	4	3	f	\N
51	3	3	f	\N
52	2	3	f	\N
53	1	3	f	\N
54	9	2	f	\N
55	8	2	f	\N
56	7	2	f	\N
57	6	2	f	\N
58	5	2	f	\N
59	4	2	f	\N
60	3	2	f	\N
61	2	2	f	\N
62	1	2	f	\N
63	9	1	f	\N
64	8	1	f	\N
65	7	1	f	\N
66	6	1	f	\N
67	5	1	f	\N
68	4	1	f	\N
69	3	1	f	\N
70	2	1	f	\N
71	1	1	f	\N
72	12	14	f	\N
73	11	14	f	\N
74	10	14	f	\N
75	12	13	f	\N
76	11	13	f	\N
77	10	13	f	\N
78	12	12	f	\N
79	11	12	f	\N
80	10	12	f	\N
81	12	11	f	\N
82	11	11	f	\N
83	10	11	f	\N
84	12	10	f	\N
85	11	10	f	\N
86	10	10	f	\N
87	12	9	f	\N
88	11	9	f	\N
89	10	9	f	\N
90	12	8	f	\N
91	11	8	f	\N
92	10	8	f	\N
28	8	5	t	Eerder behaald moduleattest Databanken (2024).
22	5	6	t	Vrijstelling op basis van bachelor toegepaste informatica.
13	5	7	t	Vrijstelling op basis van bachelor toegepaste informatica.
\.


--
-- Data for Name: lesgever; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesgever (lesgever_id, lesgevernummer, publieke_bio, foto_url, linkedin_url, zichtbaar_op_web, ondernemingsnummer, uurtarief, iban, in_dienst_sinds, uit_dienst_op) FROM stdin;
1	L0001	Software engineer en Python-trainer. Werkt dagelijks met backend-API's en automatisatie.	\N	\N	t	BE0234567891	72.00	BE71096123456769	2018-01-15	\N
2	L0002	Databankarchitect met twintig jaar ervaring in industriele dataplatformen. Geeft les over relationele modellering en SQL.	\N	\N	t	BE0123456789	78.50	BE68539007547034	2015-09-01	\N
3	L0003	Data scientist. Begeleidt cursisten in NumPy, Pandas en visualisatie.	\N	\N	t	BE0345678912	80.00	BE62510007547061	2020-09-01	\N
4	L0004	Analytics consultant met een achtergrond in bedrijfskunde.	\N	\N	t	BE0456789123	69.00	BE43068999999501	2022-02-01	\N
5	L0005	Projectcoach voor eindwerken en praktijkprojecten.	\N	\N	t	BE0567891234	65.00	BE72000000001616	2019-09-01	\N
\.


--
-- Data for Name: module; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.module (module_id, opleiding_id, code, naam, omschrijving, aantal_sessies, vrijstelbaar, eindproef, volgorde) FROM stdin;
1	9	PY-BASIS	Leren programmeren in Python	Kennismaking met de basisprincipes van programmeren en ontwikkeling van logisch inzicht om eenvoudige Python-programma's op te bouwen.	16	t	f	1
2	9	PY-OO	OO Programmeren in Python	Verdieping in objectgeorienteerd programmeren met aandacht voor het structureren van software via klassen die moeiteloos samenwerken.	16	t	f	2
3	9	PY-DB	Databanken	De essentiele vaardigheden voor het ontwerpen en beheren van databanken en het schrijven van efficiente SQL-query's voor correcte en veilige dataverwerking.	12	t	f	3
4	9	PY-NUMPY	Python for data science: NumPy	Werken met NumPy voor het structureren van data en het uitvoeren van performante berekeningen op datasets.	7	t	f	4
5	9	PY-PANDAS	Python for data science: Pandas	Toepassen van Pandas voor het analyseren, manipuleren en structureren van data binnen een data science context.	8	f	f	5
6	9	PY-CLEAN	Data exploration & cleaning with Python	Inzicht verwerven in het opschonen, verkennen en visualiseren van data om tot betrouwbare analyses te komen.	8	f	f	6
7	9	PY-EP	EP Python data developer	Integratie van alle opgedane kennis in een praktijkgericht project met focus op data-analyse, verwerking en presentatie.	6	f	t	7
8	10	DA-STAT	Statistiek voor data-analisten	\N	10	t	f	1
9	10	DA-SQL	SQL en datamodellering	\N	12	t	f	2
10	10	DA-VIZ	Datavisualisatie met Power BI	\N	8	f	f	3
11	10	DA-EP	EP Data-analist	\N	6	f	t	4
\.


--
-- Data for Name: niveau; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.niveau (niveau_code, omschrijving, volgorde) FROM stdin;
beginner	Beginner	1
gevorderd	Gevorderd	2
\.


--
-- Data for Name: opleiding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opleiding (opleiding_id, subcategorie_id, vorm_code, niveau_code, naam, slug, korte_omschrijving, lange_omschrijving, doelgroep, duur_in_jaren, ai_geintegreerd, nieuw, gepubliceerd, aangemaakt_op, gewijzigd_op) FROM stdin;
1	1	dag	gevorderd	Cybersecurity specialist	cybersecurity-specialist-engineer-en-analist	Het volledige traject van cybersecurity engineer en analist.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
2	1	avond	gevorderd	Cybersecurity analist	cybersecurity-analist	Detecteer, analyseer en rapporteer securityincidenten.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
3	1	etraject	gevorderd	Local large language model specialist	local-large-language-model-specialist-english-online	Zet lokaal draaiende large language models op en beheer ze.	\N	\N	1.0	t	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
4	1	etraject	gevorderd	Data Steward	data-steward-online	Bewaak de kwaliteit, herkomst en governance van data in je organisatie.	\N	\N	1.0	f	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
5	1	avond	beginner	IT fundamentals	it-fundamentals	De basisbegrippen van IT voor wie zonder voorkennis start.	\N	\N	0.5	f	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
6	1	avond	beginner	Software developer Full stack foundations & AI assistance	software-developer-full-stack-foundations-ai	De fundamenten van full stack development, ondersteund door AI.	\N	\N	1.0	t	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
7	1	avond	beginner	Software developer Python & AI assistance	software-developer-python-ai	Ontwikkel software in Python en leer AI-assistenten inzetten in je ontwikkelproces.	\N	\N	1.0	t	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
8	1	bijscholing	beginner	Game engine fundamentals	game-engine-fundamentals	Maak kennis met de bouwstenen van een moderne game engine.	\N	\N	0.5	f	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
10	1	avond	beginner	Data-analist	data-analist	Data verzamelen, analyseren en visualiseren om betere beslissingen te ondersteunen.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
11	1	avond	beginner	Businessanalist	business-analist-bedrijfsanalist-ict	Leer bedrijfsprocessen analyseren en vertalen naar heldere IT-vereisten.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
12	4	etraject	beginner	UX Designer (online)	ux-designer-online	Dezelfde UX-competenties, volledig op eigen tempo.	\N	\N	1.0	t	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
13	4	avond	beginner	UX Designer	user-experience-designer-ux-designer	Ontwerp digitale producten die mensen graag gebruiken.	\N	\N	1.0	t	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
14	5	voltijds	beginner	Netwerkbeheerder (voltijds)	voltijdse-dagopleiding-netwerkbeheerder	Netwerkbeheerder in een voltijds dagtraject.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
15	5	avond	beginner	Netwerkbeheerder	netwerkbeheerder	Bouw, beheer en beveilig bedrijfsnetwerken.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
16	8	dag	beginner	Cybersecurity administrator	cybersecurity-administrator	De operationele kant van cybersecurity.	\N	\N	1.0	f	t	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
17	8	avond	gevorderd	Cybersecurity engineer	cybersecurity-engineer	Beveilig infrastructuur en applicaties tegen aanvallen.	\N	\N	1.0	f	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.511245
9	1	avond	beginner	Python data developer	python-data-developer	Een Python data developer gebruikt Python om dataprocessen en systemen te ontwikkelen, beheren en optimaliseren.	Je leert eerst programmeren in Python, waarbij je ook leert hoe AI wordt ingezet om code te verbeteren en problemen op te lossen. Daarna leer je het opzetten, onderhouden en bevragen van databanken. In de tweede helft wordt de opgedane kennis ingezet op het verzamelen, analyseren en visualiseren van data met NumPy, Pandas en Matplotlib.	Iedereen die een professionele carriere als Python data developer wil uitbouwen. Voorkennis is niet vereist, een solide basis Engels en logisch redeneren wel. Je bent minstens 18 jaar in het kalenderjaar waarin de opleiding start.	1.0	t	f	t	2026-08-24 17:42:12.511245	2026-08-24 17:42:12.512896
\.


--
-- Data for Name: opleidingsperiode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opleidingsperiode (periode_id, opleiding_id, campus_id, code, academiejaar, startdatum, einddatum, dagdeel, prijs, max_cursisten, inschrijven_tot, status, lessenrooster_url, aangemaakt_op, gewijzigd_op) FROM stdin;
1	9	1	PDD-2026-GENT	2026-2027	2026-09-14	2027-06-25	avond	1010.00	18	2026-09-13	open	https://mijn.syntra-mvl.be/Lessenrooster?cursus=PDD-2026-GENT	2026-08-24 17:42:12.515047	2026-08-24 17:42:12.515047
2	9	1	PDD-2027-GENT	2027-2028	2027-09-13	2028-06-23	avond	1045.00	18	2027-09-12	open	https://mijn.syntra-mvl.be/Lessenrooster?cursus=PDD-2027-GENT	2026-08-24 17:42:12.515047	2026-08-24 17:42:12.515047
3	10	1	DA-2026-GENT	2026-2027	2026-09-15	2027-06-24	avond	1150.00	16	2026-09-14	open	\N	2026-08-24 17:42:12.516074	2026-08-24 17:42:12.516074
\.


--
-- Data for Name: opleidingsvorm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opleidingsvorm (vorm_code, omschrijving, volgorde) FROM stdin;
avond	Avondopleiding	1
dag	Dagopleiding	2
voltijds	Voltijdse dagopleiding	3
etraject	E-traject	4
bijscholing	Bijscholingen en specialisaties	5
\.


--
-- Data for Name: periode_module; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periode_module (periode_module_id, periode_id, module_id, volgorde, startdatum, einddatum) FROM stdin;
15	3	11	4	2026-09-15	2027-06-24
16	3	10	3	2026-09-15	2027-06-24
17	3	9	2	2026-09-15	2027-06-24
18	3	8	1	2026-09-15	2027-06-24
7	1	1	1	2026-09-14	2026-11-16
6	1	2	2	2026-11-17	2027-01-26
5	1	3	3	2027-01-27	2027-03-09
4	1	4	4	2027-03-10	2027-04-13
3	1	5	5	2027-04-14	2027-05-18
2	1	6	6	2027-05-19	2027-06-08
1	1	7	7	2027-06-09	2027-06-25
14	2	1	1	2027-09-13	2027-11-15
13	2	2	2	2027-11-16	2028-01-25
12	2	3	3	2028-01-26	2028-03-07
11	2	4	4	2028-03-08	2028-04-11
10	2	5	5	2028-04-12	2028-05-16
9	2	6	6	2028-05-17	2028-06-06
8	2	7	7	2028-06-07	2028-06-23
\.


--
-- Data for Name: periode_module_lesgever; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periode_module_lesgever (periode_module_id, lesgever_id, rol, toegewezen_op) FROM stdin;
1	5	hoofddocent	2026-08-24 17:42:12.519807
2	4	hoofddocent	2026-08-24 17:42:12.519807
4	3	hoofddocent	2026-08-24 17:42:12.519807
3	3	hoofddocent	2026-08-24 17:42:12.519807
1	3	co-docent	2026-08-24 17:42:12.519807
5	2	hoofddocent	2026-08-24 17:42:12.519807
7	1	hoofddocent	2026-08-24 17:42:12.519807
6	1	hoofddocent	2026-08-24 17:42:12.519807
8	5	hoofddocent	2026-08-24 17:42:12.519807
10	4	hoofddocent	2026-08-24 17:42:12.519807
9	4	hoofddocent	2026-08-24 17:42:12.519807
11	3	hoofddocent	2026-08-24 17:42:12.519807
12	2	hoofddocent	2026-08-24 17:42:12.519807
14	1	hoofddocent	2026-08-24 17:42:12.519807
13	1	hoofddocent	2026-08-24 17:42:12.519807
\.


--
-- Data for Name: persoon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.persoon (persoon_id, voornaam, familienaam, email, telefoon, rijksregisternr, geboortedatum, adres, postcode, gemeente, land, aangemaakt_op, gewijzigd_op) FROM stdin;
1	Sofie	Maes	sofie.maes@syntra-mvl.be	+32 476 22 33 44	\N	\N	\N	\N	\N	BE	2026-08-24 17:42:12.51857	2026-08-24 17:42:12.51857
2	Wim	Segers	wim.segers@syntra-mvl.be	+32 475 11 22 33	\N	\N	\N	\N	\N	BE	2026-08-24 17:42:12.51857	2026-08-24 17:42:12.51857
3	Karim	El Amrani	karim.elamrani@syntra-mvl.be	+32 477 33 44 55	\N	\N	\N	\N	\N	BE	2026-08-24 17:42:12.51857	2026-08-24 17:42:12.51857
4	An	Peeters	an.peeters@syntra-mvl.be	+32 478 44 55 66	\N	\N	\N	\N	\N	BE	2026-08-24 17:42:12.51857	2026-08-24 17:42:12.51857
5	Tom	De Smet	tom.desmet@syntra-mvl.be	+32 479 55 66 77	\N	\N	\N	\N	\N	BE	2026-08-24 17:42:12.51857	2026-08-24 17:42:12.51857
6	Ella	Janssens	ella.janssens@example.be	+32 470 10 20 30	95031212345	1995-03-12	Kerkstraat 12	9000	Gent	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
7	Milan	Vermeulen	milan.vermeulen@example.be	+32 471 11 21 31	90072423456	1990-07-24	Dorpsplein 4	9100	Sint-Niklaas	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
8	Fatima	Boujida	fatima.boujida@example.be	+32 472 12 22 32	98110234567	1998-11-02	Molenstraat 77	9300	Aalst	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
9	Jonas	De Clercq	jonas.declercq@example.be	+32 473 13 23 33	87013045678	1987-01-30	Stationsstraat 9	9050	Gentbrugge	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
10	Amber	Willems	amber.willems@example.be	+32 474 14 24 34	00051856789	2000-05-18	Lindelaan 23	9040	Sint-Amandsberg	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
11	Kobe	Verhaeghe	kobe.verhaeghe@example.be	+32 475 15 25 35	93090967891	1993-09-09	Veldstraat 101	9000	Gent	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
12	Nina	Dhondt	nina.dhondt@example.be	+32 476 16 26 36	96122178912	1996-12-21	Meersstraat 8	9051	Sint-Denijs-Westrem	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
13	Yassine	Cherkaoui	yassine.cherkaoui@example.be	+32 477 17 27 37	92021489123	1992-02-14	Nieuwstraat 15	9200	Dendermonde	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
14	Lore	Van Damme	lore.vandamme@example.be	+32 478 18 28 38	99080591234	1999-08-05	Bergstraat 32	9700	Oudenaarde	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
15	Bram	Coppens	bram.coppens@example.be	+32 479 19 29 39	85042792345	1985-04-27	Zandstraat 56	9250	Waasmunster	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
16	Iris	Lemmens	iris.lemmens@example.be	+32 470 20 30 40	97061193456	1997-06-11	Parklaan 3	9000	Gent	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
17	Simon	Roelandt	simon.roelandt@example.be	+32 471 21 31 41	91101994567	1991-10-19	Beukenlaan 44	9120	Beveren	BE	2026-08-24 17:42:12.521505	2026-08-24 17:42:12.521505
\.


--
-- Data for Name: subcategorie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcategorie (subcategorie_id, categorie_id, naam, slug, omschrijving, afbeelding_url, volgorde, gepubliceerd, aangemaakt_op, gewijzigd_op) FROM stdin;
1	6	Data & software development	data-software-development	Geen enkele sector biedt zoveel mogelijkheden en toekomstperspectief als de IT-sector. Ontwikkel je vaardigheden als data-analist, software-ontwikkelaar of IT-consultant.	https://syntra-mvl.be/wp-content/uploads/2023/04/card__data.jpeg	1	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
2	6	Foto & video	foto-video	\N	\N	2	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
3	6	Gaming en animatie	gaming-en-animatie	\N	\N	3	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
4	6	Grafische vormgeving	grafische-vormgeving	\N	\N	4	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
5	6	Hardware & telecom	hardware-telecom	\N	\N	5	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
6	6	Media	media	\N	\N	6	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
7	6	Podiumtechnieken	podiumtechnieken	\N	\N	7	t	2026-08-24 17:42:12.509726	2026-08-24 17:42:12.509726
8	15	Security	security	\N	\N	1	t	2026-08-24 17:42:12.510818	2026-08-24 17:42:12.510818
\.


--
-- Name: betaling_betaling_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.betaling_betaling_id_seq', 10, true);


--
-- Name: campus_campus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campus_campus_id_seq', 3, true);


--
-- Name: categorie_categorie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorie_categorie_id_seq', 18, true);


--
-- Name: evaluatie_evaluatie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evaluatie_evaluatie_id_seq', 17, true);


--
-- Name: inschrijving_inschrijving_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inschrijving_inschrijving_id_seq', 20, true);


--
-- Name: inschrijving_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inschrijving_log_log_id_seq', 22, true);


--
-- Name: inschrijving_module_inschrijving_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inschrijving_module_inschrijving_module_id_seq', 100, true);


--
-- Name: module_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.module_module_id_seq', 15, true);


--
-- Name: opleiding_opleiding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.opleiding_opleiding_id_seq', 21, true);


--
-- Name: opleidingsperiode_periode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.opleidingsperiode_periode_id_seq', 7, true);


--
-- Name: periode_module_periode_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periode_module_periode_module_id_seq', 22, true);


--
-- Name: persoon_persoon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.persoon_persoon_id_seq', 21, true);


--
-- Name: subcategorie_subcategorie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subcategorie_subcategorie_id_seq', 10, true);


--
-- Name: betaling betaling_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.betaling
    ADD CONSTRAINT betaling_pkey PRIMARY KEY (betaling_id);


--
-- Name: campus campus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campus
    ADD CONSTRAINT campus_pkey PRIMARY KEY (campus_id);


--
-- Name: categorie categorie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorie
    ADD CONSTRAINT categorie_pkey PRIMARY KEY (categorie_id);


--
-- Name: cursist cursist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursist
    ADD CONSTRAINT cursist_pkey PRIMARY KEY (cursist_id);


--
-- Name: evaluatie evaluatie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluatie
    ADD CONSTRAINT evaluatie_pkey PRIMARY KEY (evaluatie_id);


--
-- Name: inschrijving_log inschrijving_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving_log
    ADD CONSTRAINT inschrijving_log_pkey PRIMARY KEY (log_id);


--
-- Name: inschrijving_module inschrijving_module_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving_module
    ADD CONSTRAINT inschrijving_module_pkey PRIMARY KEY (inschrijving_module_id);


--
-- Name: inschrijving inschrijving_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving
    ADD CONSTRAINT inschrijving_pkey PRIMARY KEY (inschrijving_id);


--
-- Name: lesgever lesgever_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesgever
    ADD CONSTRAINT lesgever_pkey PRIMARY KEY (lesgever_id);


--
-- Name: module module_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module
    ADD CONSTRAINT module_pkey PRIMARY KEY (module_id);


--
-- Name: niveau niveau_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveau
    ADD CONSTRAINT niveau_pkey PRIMARY KEY (niveau_code);


--
-- Name: opleiding opleiding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT opleiding_pkey PRIMARY KEY (opleiding_id);


--
-- Name: opleidingsperiode opleidingsperiode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsperiode
    ADD CONSTRAINT opleidingsperiode_pkey PRIMARY KEY (periode_id);


--
-- Name: opleidingsvorm opleidingsvorm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsvorm
    ADD CONSTRAINT opleidingsvorm_pkey PRIMARY KEY (vorm_code);


--
-- Name: periode_module periode_module_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module
    ADD CONSTRAINT periode_module_pkey PRIMARY KEY (periode_module_id);


--
-- Name: persoon persoon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persoon
    ADD CONSTRAINT persoon_pkey PRIMARY KEY (persoon_id);


--
-- Name: periode_module_lesgever pk_periode_module_lesgever; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module_lesgever
    ADD CONSTRAINT pk_periode_module_lesgever PRIMARY KEY (periode_module_id, lesgever_id);


--
-- Name: subcategorie subcategorie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorie
    ADD CONSTRAINT subcategorie_pkey PRIMARY KEY (subcategorie_id);


--
-- Name: betaling uq_betaling_referentie; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.betaling
    ADD CONSTRAINT uq_betaling_referentie UNIQUE (referentie);


--
-- Name: campus uq_campus_naam; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campus
    ADD CONSTRAINT uq_campus_naam UNIQUE (naam);


--
-- Name: categorie uq_categorie_naam; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorie
    ADD CONSTRAINT uq_categorie_naam UNIQUE (naam);


--
-- Name: categorie uq_categorie_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorie
    ADD CONSTRAINT uq_categorie_slug UNIQUE (slug);


--
-- Name: cursist uq_cursist_nummer; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursist
    ADD CONSTRAINT uq_cursist_nummer UNIQUE (cursistnummer);


--
-- Name: evaluatie uq_evaluatie_poging; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluatie
    ADD CONSTRAINT uq_evaluatie_poging UNIQUE (inschrijving_module_id, poging);


--
-- Name: inschrijving uq_inschrijving; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving
    ADD CONSTRAINT uq_inschrijving UNIQUE (cursist_id, periode_id);


--
-- Name: inschrijving_module uq_inschrijving_module; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving_module
    ADD CONSTRAINT uq_inschrijving_module UNIQUE (inschrijving_id, periode_module_id);


--
-- Name: lesgever uq_lesgever_nummer; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesgever
    ADD CONSTRAINT uq_lesgever_nummer UNIQUE (lesgevernummer);


--
-- Name: module uq_module_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module
    ADD CONSTRAINT uq_module_code UNIQUE (opleiding_id, code);


--
-- Name: niveau uq_niveau_omschrijving; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveau
    ADD CONSTRAINT uq_niveau_omschrijving UNIQUE (omschrijving);


--
-- Name: opleiding uq_opleiding_naam; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT uq_opleiding_naam UNIQUE (subcategorie_id, naam);


--
-- Name: opleiding uq_opleiding_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT uq_opleiding_slug UNIQUE (slug);


--
-- Name: opleidingsvorm uq_opleidingsvorm_omschrijving; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsvorm
    ADD CONSTRAINT uq_opleidingsvorm_omschrijving UNIQUE (omschrijving);


--
-- Name: opleidingsperiode uq_periode_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsperiode
    ADD CONSTRAINT uq_periode_code UNIQUE (code);


--
-- Name: periode_module uq_periode_module; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module
    ADD CONSTRAINT uq_periode_module UNIQUE (periode_id, module_id);


--
-- Name: subcategorie uq_subcategorie_naam; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorie
    ADD CONSTRAINT uq_subcategorie_naam UNIQUE (categorie_id, naam);


--
-- Name: subcategorie uq_subcategorie_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorie
    ADD CONSTRAINT uq_subcategorie_slug UNIQUE (slug);


--
-- Name: idx_betaling_inschrijving; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_betaling_inschrijving ON public.betaling USING btree (inschrijving_id);


--
-- Name: idx_evaluatie_im; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_evaluatie_im ON public.evaluatie USING btree (inschrijving_module_id);


--
-- Name: idx_evaluatie_lesgever; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_evaluatie_lesgever ON public.evaluatie USING btree (lesgever_id);


--
-- Name: idx_im_inschrijving; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_im_inschrijving ON public.inschrijving_module USING btree (inschrijving_id);


--
-- Name: idx_im_periode_module; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_im_periode_module ON public.inschrijving_module USING btree (periode_module_id);


--
-- Name: idx_inschrijving_cursist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inschrijving_cursist ON public.inschrijving USING btree (cursist_id);


--
-- Name: idx_inschrijving_periode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inschrijving_periode ON public.inschrijving USING btree (periode_id, status);


--
-- Name: idx_log_inschrijving; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_log_inschrijving ON public.inschrijving_log USING btree (inschrijving_id);


--
-- Name: idx_module_opleiding; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_module_opleiding ON public.module USING btree (opleiding_id, volgorde);


--
-- Name: idx_opleiding_naam; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opleiding_naam ON public.opleiding USING btree (lower((naam)::text));


--
-- Name: idx_opleiding_niveau; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opleiding_niveau ON public.opleiding USING btree (niveau_code);


--
-- Name: idx_opleiding_subcategorie; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opleiding_subcategorie ON public.opleiding USING btree (subcategorie_id);


--
-- Name: idx_opleiding_vorm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opleiding_vorm ON public.opleiding USING btree (vorm_code);


--
-- Name: idx_periode_campus; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periode_campus ON public.opleidingsperiode USING btree (campus_id);


--
-- Name: idx_periode_module_module; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periode_module_module ON public.periode_module USING btree (module_id);


--
-- Name: idx_periode_module_periode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periode_module_periode ON public.periode_module USING btree (periode_id, volgorde);


--
-- Name: idx_periode_opleiding; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periode_opleiding ON public.opleidingsperiode USING btree (opleiding_id, startdatum);


--
-- Name: idx_periode_startdatum; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_periode_startdatum ON public.opleidingsperiode USING btree (startdatum) WHERE ((status)::text = ANY ((ARRAY['gepland'::character varying, 'open'::character varying])::text[]));


--
-- Name: idx_persoon_naam; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_persoon_naam ON public.persoon USING btree (lower((familienaam)::text), lower((voornaam)::text));


--
-- Name: idx_pml_lesgever; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pml_lesgever ON public.periode_module_lesgever USING btree (lesgever_id);


--
-- Name: idx_subcategorie_categorie; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subcategorie_categorie ON public.subcategorie USING btree (categorie_id, volgorde);


--
-- Name: uq_persoon_email_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_persoon_email_lower ON public.persoon USING btree (lower((email)::text));


--
-- Name: categorie trg_categorie_gewijzigd; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_categorie_gewijzigd BEFORE UPDATE ON public.categorie FOR EACH ROW EXECUTE FUNCTION public.fn_zet_gewijzigd_op();


--
-- Name: inschrijving trg_inschrijving_log; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_inschrijving_log AFTER INSERT OR UPDATE ON public.inschrijving FOR EACH ROW EXECUTE FUNCTION public.fn_log_inschrijving_status();


--
-- Name: opleiding trg_opleiding_gewijzigd; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_opleiding_gewijzigd BEFORE UPDATE ON public.opleiding FOR EACH ROW EXECUTE FUNCTION public.fn_zet_gewijzigd_op();


--
-- Name: opleidingsperiode trg_periode_gewijzigd; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_periode_gewijzigd BEFORE UPDATE ON public.opleidingsperiode FOR EACH ROW EXECUTE FUNCTION public.fn_zet_gewijzigd_op();


--
-- Name: persoon trg_persoon_gewijzigd; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_persoon_gewijzigd BEFORE UPDATE ON public.persoon FOR EACH ROW EXECUTE FUNCTION public.fn_zet_gewijzigd_op();


--
-- Name: subcategorie trg_subcategorie_gewijzigd; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_subcategorie_gewijzigd BEFORE UPDATE ON public.subcategorie FOR EACH ROW EXECUTE FUNCTION public.fn_zet_gewijzigd_op();


--
-- Name: betaling fk_betaling_inschrijving; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.betaling
    ADD CONSTRAINT fk_betaling_inschrijving FOREIGN KEY (inschrijving_id) REFERENCES public.inschrijving(inschrijving_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cursist fk_cursist_persoon; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursist
    ADD CONSTRAINT fk_cursist_persoon FOREIGN KEY (cursist_id) REFERENCES public.persoon(persoon_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: evaluatie fk_evaluatie_im; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluatie
    ADD CONSTRAINT fk_evaluatie_im FOREIGN KEY (inschrijving_module_id) REFERENCES public.inschrijving_module(inschrijving_module_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: evaluatie fk_evaluatie_lesgever; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluatie
    ADD CONSTRAINT fk_evaluatie_lesgever FOREIGN KEY (lesgever_id) REFERENCES public.lesgever(lesgever_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inschrijving_module fk_im_inschrijving; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving_module
    ADD CONSTRAINT fk_im_inschrijving FOREIGN KEY (inschrijving_id) REFERENCES public.inschrijving(inschrijving_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inschrijving_module fk_im_periode_module; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving_module
    ADD CONSTRAINT fk_im_periode_module FOREIGN KEY (periode_module_id) REFERENCES public.periode_module(periode_module_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inschrijving fk_inschrijving_cursist; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving
    ADD CONSTRAINT fk_inschrijving_cursist FOREIGN KEY (cursist_id) REFERENCES public.cursist(cursist_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inschrijving fk_inschrijving_periode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inschrijving
    ADD CONSTRAINT fk_inschrijving_periode FOREIGN KEY (periode_id) REFERENCES public.opleidingsperiode(periode_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lesgever fk_lesgever_persoon; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesgever
    ADD CONSTRAINT fk_lesgever_persoon FOREIGN KEY (lesgever_id) REFERENCES public.persoon(persoon_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: module fk_module_opleiding; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module
    ADD CONSTRAINT fk_module_opleiding FOREIGN KEY (opleiding_id) REFERENCES public.opleiding(opleiding_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: opleiding fk_opleiding_niveau; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT fk_opleiding_niveau FOREIGN KEY (niveau_code) REFERENCES public.niveau(niveau_code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opleiding fk_opleiding_subcategorie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT fk_opleiding_subcategorie FOREIGN KEY (subcategorie_id) REFERENCES public.subcategorie(subcategorie_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opleiding fk_opleiding_vorm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleiding
    ADD CONSTRAINT fk_opleiding_vorm FOREIGN KEY (vorm_code) REFERENCES public.opleidingsvorm(vorm_code) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opleidingsperiode fk_periode_campus; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsperiode
    ADD CONSTRAINT fk_periode_campus FOREIGN KEY (campus_id) REFERENCES public.campus(campus_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: periode_module fk_periode_module_module; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module
    ADD CONSTRAINT fk_periode_module_module FOREIGN KEY (module_id) REFERENCES public.module(module_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: periode_module fk_periode_module_periode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module
    ADD CONSTRAINT fk_periode_module_periode FOREIGN KEY (periode_id) REFERENCES public.opleidingsperiode(periode_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: opleidingsperiode fk_periode_opleiding; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opleidingsperiode
    ADD CONSTRAINT fk_periode_opleiding FOREIGN KEY (opleiding_id) REFERENCES public.opleiding(opleiding_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: periode_module_lesgever fk_pml_lesgever; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module_lesgever
    ADD CONSTRAINT fk_pml_lesgever FOREIGN KEY (lesgever_id) REFERENCES public.lesgever(lesgever_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: periode_module_lesgever fk_pml_periode_module; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periode_module_lesgever
    ADD CONSTRAINT fk_pml_periode_module FOREIGN KEY (periode_module_id) REFERENCES public.periode_module(periode_module_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subcategorie fk_subcategorie_categorie; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcategorie
    ADD CONSTRAINT fk_subcategorie_categorie FOREIGN KEY (categorie_id) REFERENCES public.categorie(categorie_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO syntra_web;
GRANT USAGE ON SCHEMA public TO syntra_medewerker;
GRANT USAGE ON SCHEMA public TO syntra_lesgever;
GRANT USAGE ON SCHEMA public TO syntra_admin;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.armor(bytea) TO syntra_admin;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO syntra_admin;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.crypt(text, text) TO syntra_admin;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.dearmor(text) TO syntra_admin;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.digest(bytea, text) TO syntra_admin;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.digest(text, text) TO syntra_admin;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION fn_aantal_ingeschreven(p_periode_id integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) TO syntra_web;
GRANT ALL ON FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) TO syntra_lesgever;
GRANT ALL ON FUNCTION public.fn_aantal_ingeschreven(p_periode_id integer) TO syntra_admin;


--
-- Name: FUNCTION fn_leeftijd(p_geboortedatum date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_leeftijd(p_geboortedatum date) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_leeftijd(p_geboortedatum date) TO syntra_lesgever;
GRANT ALL ON FUNCTION public.fn_leeftijd(p_geboortedatum date) TO syntra_admin;


--
-- Name: FUNCTION fn_log_inschrijving_status(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_log_inschrijving_status() TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_log_inschrijving_status() TO syntra_admin;


--
-- Name: FUNCTION fn_module_geslaagd(p_inschrijving_module_id integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_module_geslaagd(p_inschrijving_module_id integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_module_geslaagd(p_inschrijving_module_id integer) TO syntra_lesgever;
GRANT ALL ON FUNCTION public.fn_module_geslaagd(p_inschrijving_module_id integer) TO syntra_admin;


--
-- Name: FUNCTION fn_openstaand_saldo(p_inschrijving_id integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_openstaand_saldo(p_inschrijving_id integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_openstaand_saldo(p_inschrijving_id integer) TO syntra_lesgever;
GRANT ALL ON FUNCTION public.fn_openstaand_saldo(p_inschrijving_id integer) TO syntra_admin;


--
-- Name: FUNCTION fn_vrije_plaatsen(p_periode_id integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) TO syntra_web;
GRANT ALL ON FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) TO syntra_lesgever;
GRANT ALL ON FUNCTION public.fn_vrije_plaatsen(p_periode_id integer) TO syntra_admin;


--
-- Name: FUNCTION fn_zet_gewijzigd_op(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_zet_gewijzigd_op() TO syntra_medewerker;
GRANT ALL ON FUNCTION public.fn_zet_gewijzigd_op() TO syntra_admin;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO syntra_admin;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO syntra_medewerker;
GRANT ALL ON FUNCTION public.gen_random_uuid() TO syntra_admin;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.gen_salt(text) TO syntra_admin;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO syntra_admin;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.hmac(text, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO syntra_admin;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO syntra_admin;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO syntra_admin;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO syntra_medewerker;
GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO syntra_admin;


--
-- Name: PROCEDURE sp_betaling_registreren(IN p_inschrijving_id integer, IN p_bedrag numeric, IN p_methode character varying, IN p_referentie character varying, IN p_datum date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_betaling_registreren(IN p_inschrijving_id integer, IN p_bedrag numeric, IN p_methode character varying, IN p_referentie character varying, IN p_datum date) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_betaling_registreren(IN p_inschrijving_id integer, IN p_bedrag numeric, IN p_methode character varying, IN p_referentie character varying, IN p_datum date) TO syntra_admin;


--
-- Name: PROCEDURE sp_categorie_toevoegen(IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_categorie_toevoegen(IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_categorie_toevoegen(IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) TO syntra_admin;


--
-- Name: PROCEDURE sp_cursist_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_geboortedatum date, IN p_rijksregisternr character, IN p_adres character varying, IN p_postcode character varying, IN p_gemeente character varying, IN p_hoogste_diploma character varying, IN p_wachtwoord character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_cursist_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_geboortedatum date, IN p_rijksregisternr character, IN p_adres character varying, IN p_postcode character varying, IN p_gemeente character varying, IN p_hoogste_diploma character varying, IN p_wachtwoord character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_cursist_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_geboortedatum date, IN p_rijksregisternr character, IN p_adres character varying, IN p_postcode character varying, IN p_gemeente character varying, IN p_hoogste_diploma character varying, IN p_wachtwoord character varying) TO syntra_admin;


--
-- Name: PROCEDURE sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying, IN p_feedback character varying, IN p_datum date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying, IN p_feedback character varying, IN p_datum date) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying, IN p_feedback character varying, IN p_datum date) TO syntra_lesgever;
GRANT ALL ON PROCEDURE public.sp_evaluatie_registreren(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_score numeric, IN p_lesgever_email character varying, IN p_feedback character varying, IN p_datum date) TO syntra_admin;


--
-- Name: PROCEDURE sp_inschrijven(IN p_email character varying, IN p_periode_code character varying, IN p_korting numeric, IN p_korting_tekst character varying, IN p_opmerking character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_inschrijven(IN p_email character varying, IN p_periode_code character varying, IN p_korting numeric, IN p_korting_tekst character varying, IN p_opmerking character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_inschrijven(IN p_email character varying, IN p_periode_code character varying, IN p_korting numeric, IN p_korting_tekst character varying, IN p_opmerking character varying) TO syntra_admin;


--
-- Name: PROCEDURE sp_inschrijving_annuleren(IN p_inschrijving_id integer, IN p_reden character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_inschrijving_annuleren(IN p_inschrijving_id integer, IN p_reden character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_inschrijving_annuleren(IN p_inschrijving_id integer, IN p_reden character varying) TO syntra_admin;


--
-- Name: PROCEDURE sp_inschrijving_bevestigen(IN p_inschrijving_id integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_inschrijving_bevestigen(IN p_inschrijving_id integer) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_inschrijving_bevestigen(IN p_inschrijving_id integer) TO syntra_admin;


--
-- Name: PROCEDURE sp_lesgever_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_publieke_bio character varying, IN p_ondernemingsnummer character varying, IN p_uurtarief numeric, IN p_iban character varying, IN p_in_dienst_sinds date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_lesgever_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_publieke_bio character varying, IN p_ondernemingsnummer character varying, IN p_uurtarief numeric, IN p_iban character varying, IN p_in_dienst_sinds date) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_lesgever_toevoegen(IN p_voornaam character varying, IN p_familienaam character varying, IN p_email character varying, IN p_telefoon character varying, IN p_publieke_bio character varying, IN p_ondernemingsnummer character varying, IN p_uurtarief numeric, IN p_iban character varying, IN p_in_dienst_sinds date) TO syntra_admin;


--
-- Name: PROCEDURE sp_lesgever_toewijzen(IN p_periode_code character varying, IN p_module_code character varying, IN p_email character varying, IN p_rol character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_lesgever_toewijzen(IN p_periode_code character varying, IN p_module_code character varying, IN p_email character varying, IN p_rol character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_lesgever_toewijzen(IN p_periode_code character varying, IN p_module_code character varying, IN p_email character varying, IN p_rol character varying) TO syntra_admin;


--
-- Name: PROCEDURE sp_module_plannen(IN p_periode_code character varying, IN p_module_code character varying, IN p_startdatum date, IN p_einddatum date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_module_plannen(IN p_periode_code character varying, IN p_module_code character varying, IN p_startdatum date, IN p_einddatum date) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_module_plannen(IN p_periode_code character varying, IN p_module_code character varying, IN p_startdatum date, IN p_einddatum date) TO syntra_admin;


--
-- Name: PROCEDURE sp_module_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_naam character varying, IN p_omschrijving character varying, IN p_aantal_sessies integer, IN p_vrijstelbaar boolean, IN p_eindproef boolean, IN p_volgorde integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_module_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_naam character varying, IN p_omschrijving character varying, IN p_aantal_sessies integer, IN p_vrijstelbaar boolean, IN p_eindproef boolean, IN p_volgorde integer) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_module_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_naam character varying, IN p_omschrijving character varying, IN p_aantal_sessies integer, IN p_vrijstelbaar boolean, IN p_eindproef boolean, IN p_volgorde integer) TO syntra_admin;


--
-- Name: PROCEDURE sp_opleiding_toevoegen(IN p_subcategorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_vorm_code character varying, IN p_niveau_code character varying, IN p_korte_omschrijving character varying, IN p_lange_omschrijving character varying, IN p_doelgroep character varying, IN p_duur_in_jaren numeric, IN p_ai_geintegreerd boolean, IN p_nieuw boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_opleiding_toevoegen(IN p_subcategorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_vorm_code character varying, IN p_niveau_code character varying, IN p_korte_omschrijving character varying, IN p_lange_omschrijving character varying, IN p_doelgroep character varying, IN p_duur_in_jaren numeric, IN p_ai_geintegreerd boolean, IN p_nieuw boolean) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_opleiding_toevoegen(IN p_subcategorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_vorm_code character varying, IN p_niveau_code character varying, IN p_korte_omschrijving character varying, IN p_lange_omschrijving character varying, IN p_doelgroep character varying, IN p_duur_in_jaren numeric, IN p_ai_geintegreerd boolean, IN p_nieuw boolean) TO syntra_admin;


--
-- Name: PROCEDURE sp_periode_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_academiejaar character varying, IN p_campus character varying, IN p_startdatum date, IN p_einddatum date, IN p_prijs numeric, IN p_max_cursisten integer, IN p_dagdeel character varying, IN p_lessenrooster_url character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_periode_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_academiejaar character varying, IN p_campus character varying, IN p_startdatum date, IN p_einddatum date, IN p_prijs numeric, IN p_max_cursisten integer, IN p_dagdeel character varying, IN p_lessenrooster_url character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_periode_toevoegen(IN p_opleiding_slug character varying, IN p_code character varying, IN p_academiejaar character varying, IN p_campus character varying, IN p_startdatum date, IN p_einddatum date, IN p_prijs numeric, IN p_max_cursisten integer, IN p_dagdeel character varying, IN p_lessenrooster_url character varying) TO syntra_admin;


--
-- Name: PROCEDURE sp_subcategorie_toevoegen(IN p_categorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_subcategorie_toevoegen(IN p_categorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_subcategorie_toevoegen(IN p_categorie_slug character varying, IN p_naam character varying, IN p_slug character varying, IN p_omschrijving character varying, IN p_afbeelding_url character varying, IN p_volgorde integer) TO syntra_admin;


--
-- Name: PROCEDURE sp_vrijstelling_toekennen(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_motivatie character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON PROCEDURE public.sp_vrijstelling_toekennen(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_motivatie character varying) TO syntra_medewerker;
GRANT ALL ON PROCEDURE public.sp_vrijstelling_toekennen(IN p_inschrijving_id integer, IN p_module_code character varying, IN p_motivatie character varying) TO syntra_admin;


--
-- Name: TABLE betaling; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.betaling TO syntra_medewerker;
GRANT ALL ON TABLE public.betaling TO syntra_admin;


--
-- Name: SEQUENCE betaling_betaling_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.betaling_betaling_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.betaling_betaling_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.betaling_betaling_id_seq TO syntra_admin;


--
-- Name: TABLE campus; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.campus TO syntra_medewerker;
GRANT SELECT ON TABLE public.campus TO syntra_lesgever;
GRANT ALL ON TABLE public.campus TO syntra_admin;


--
-- Name: SEQUENCE campus_campus_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.campus_campus_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.campus_campus_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.campus_campus_id_seq TO syntra_admin;


--
-- Name: TABLE categorie; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.categorie TO syntra_medewerker;
GRANT ALL ON TABLE public.categorie TO syntra_admin;


--
-- Name: SEQUENCE categorie_categorie_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.categorie_categorie_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.categorie_categorie_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.categorie_categorie_id_seq TO syntra_admin;


--
-- Name: TABLE cursist; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.cursist TO syntra_medewerker;
GRANT ALL ON TABLE public.cursist TO syntra_admin;


--
-- Name: TABLE evaluatie; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.evaluatie TO syntra_medewerker;
GRANT SELECT,INSERT ON TABLE public.evaluatie TO syntra_lesgever;
GRANT ALL ON TABLE public.evaluatie TO syntra_admin;


--
-- Name: SEQUENCE evaluatie_evaluatie_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.evaluatie_evaluatie_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.evaluatie_evaluatie_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.evaluatie_evaluatie_id_seq TO syntra_admin;


--
-- Name: TABLE inschrijving; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.inschrijving TO syntra_medewerker;
GRANT SELECT ON TABLE public.inschrijving TO syntra_lesgever;
GRANT ALL ON TABLE public.inschrijving TO syntra_admin;


--
-- Name: SEQUENCE inschrijving_inschrijving_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.inschrijving_inschrijving_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.inschrijving_inschrijving_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.inschrijving_inschrijving_id_seq TO syntra_admin;


--
-- Name: TABLE inschrijving_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.inschrijving_log TO syntra_medewerker;
GRANT ALL ON TABLE public.inschrijving_log TO syntra_admin;


--
-- Name: SEQUENCE inschrijving_log_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.inschrijving_log_log_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.inschrijving_log_log_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.inschrijving_log_log_id_seq TO syntra_admin;


--
-- Name: TABLE inschrijving_module; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.inschrijving_module TO syntra_medewerker;
GRANT SELECT ON TABLE public.inschrijving_module TO syntra_lesgever;
GRANT ALL ON TABLE public.inschrijving_module TO syntra_admin;


--
-- Name: SEQUENCE inschrijving_module_inschrijving_module_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.inschrijving_module_inschrijving_module_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.inschrijving_module_inschrijving_module_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.inschrijving_module_inschrijving_module_id_seq TO syntra_admin;


--
-- Name: TABLE lesgever; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.lesgever TO syntra_admin;


--
-- Name: COLUMN lesgever.lesgever_id; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(lesgever_id) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.lesgevernummer; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(lesgevernummer) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.publieke_bio; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(publieke_bio) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.foto_url; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(foto_url) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.linkedin_url; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(linkedin_url) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.zichtbaar_op_web; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(zichtbaar_op_web) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.in_dienst_sinds; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(in_dienst_sinds) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: COLUMN lesgever.uit_dienst_op; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(uit_dienst_op) ON TABLE public.lesgever TO syntra_medewerker;


--
-- Name: TABLE module; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.module TO syntra_medewerker;
GRANT SELECT ON TABLE public.module TO syntra_lesgever;
GRANT ALL ON TABLE public.module TO syntra_admin;


--
-- Name: SEQUENCE module_module_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.module_module_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.module_module_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.module_module_id_seq TO syntra_admin;


--
-- Name: TABLE niveau; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.niveau TO syntra_medewerker;
GRANT ALL ON TABLE public.niveau TO syntra_admin;


--
-- Name: TABLE opleiding; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.opleiding TO syntra_medewerker;
GRANT SELECT ON TABLE public.opleiding TO syntra_lesgever;
GRANT ALL ON TABLE public.opleiding TO syntra_admin;


--
-- Name: SEQUENCE opleiding_opleiding_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.opleiding_opleiding_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.opleiding_opleiding_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.opleiding_opleiding_id_seq TO syntra_admin;


--
-- Name: TABLE opleidingsperiode; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.opleidingsperiode TO syntra_medewerker;
GRANT SELECT ON TABLE public.opleidingsperiode TO syntra_lesgever;
GRANT ALL ON TABLE public.opleidingsperiode TO syntra_admin;


--
-- Name: SEQUENCE opleidingsperiode_periode_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.opleidingsperiode_periode_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.opleidingsperiode_periode_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.opleidingsperiode_periode_id_seq TO syntra_admin;


--
-- Name: TABLE opleidingsvorm; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.opleidingsvorm TO syntra_medewerker;
GRANT ALL ON TABLE public.opleidingsvorm TO syntra_admin;


--
-- Name: TABLE periode_module; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.periode_module TO syntra_medewerker;
GRANT SELECT ON TABLE public.periode_module TO syntra_lesgever;
GRANT ALL ON TABLE public.periode_module TO syntra_admin;


--
-- Name: TABLE periode_module_lesgever; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.periode_module_lesgever TO syntra_medewerker;
GRANT ALL ON TABLE public.periode_module_lesgever TO syntra_admin;


--
-- Name: SEQUENCE periode_module_periode_module_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.periode_module_periode_module_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.periode_module_periode_module_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.periode_module_periode_module_id_seq TO syntra_admin;


--
-- Name: TABLE persoon; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.persoon TO syntra_medewerker;
GRANT ALL ON TABLE public.persoon TO syntra_admin;


--
-- Name: COLUMN persoon.persoon_id; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(persoon_id) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.voornaam; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(voornaam),UPDATE(voornaam) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.familienaam; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(familienaam),UPDATE(familienaam) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.email; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(email),UPDATE(email) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.telefoon; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(telefoon),UPDATE(telefoon) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.geboortedatum; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(geboortedatum) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.adres; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(adres),UPDATE(adres) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.postcode; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(postcode),UPDATE(postcode) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.gemeente; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(gemeente),UPDATE(gemeente) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: COLUMN persoon.land; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(land),UPDATE(land) ON TABLE public.persoon TO syntra_medewerker;


--
-- Name: SEQUENCE persoon_persoon_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.persoon_persoon_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.persoon_persoon_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.persoon_persoon_id_seq TO syntra_admin;


--
-- Name: TABLE subcategorie; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.subcategorie TO syntra_medewerker;
GRANT ALL ON TABLE public.subcategorie TO syntra_admin;


--
-- Name: SEQUENCE subcategorie_subcategorie_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT USAGE ON SEQUENCE public.subcategorie_subcategorie_id_seq TO syntra_medewerker;
GRANT USAGE ON SEQUENCE public.subcategorie_subcategorie_id_seq TO syntra_lesgever;
GRANT ALL ON SEQUENCE public.subcategorie_subcategorie_id_seq TO syntra_admin;


--
-- Name: TABLE vw_int_bezetting; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_bezetting TO syntra_medewerker;
GRANT ALL ON TABLE public.vw_int_bezetting TO syntra_admin;


--
-- Name: TABLE vw_int_cursist; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_cursist TO syntra_medewerker;
GRANT ALL ON TABLE public.vw_int_cursist TO syntra_admin;


--
-- Name: TABLE vw_int_klaslijst; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_klaslijst TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_int_klaslijst TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_int_klaslijst TO syntra_admin;


--
-- Name: TABLE vw_int_lesgever; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_lesgever TO syntra_medewerker;
GRANT ALL ON TABLE public.vw_int_lesgever TO syntra_admin;


--
-- Name: TABLE vw_int_lesopdracht; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_lesopdracht TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_int_lesopdracht TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_int_lesopdracht TO syntra_admin;


--
-- Name: TABLE vw_int_openstaand; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_openstaand TO syntra_medewerker;
GRANT ALL ON TABLE public.vw_int_openstaand TO syntra_admin;


--
-- Name: TABLE vw_int_resultaat; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_int_resultaat TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_int_resultaat TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_int_resultaat TO syntra_admin;


--
-- Name: TABLE vw_pub_categorie; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_categorie TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_categorie TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_categorie TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_categorie TO syntra_admin;


--
-- Name: TABLE vw_pub_lesgever; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_lesgever TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_lesgever TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_lesgever TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_lesgever TO syntra_admin;


--
-- Name: TABLE vw_pub_opleiding; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_opleiding TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_opleiding TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_opleiding TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_opleiding TO syntra_admin;


--
-- Name: TABLE vw_pub_programma; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_programma TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_programma TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_programma TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_programma TO syntra_admin;


--
-- Name: TABLE vw_pub_startmoment; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_startmoment TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_startmoment TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_startmoment TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_startmoment TO syntra_admin;


--
-- Name: TABLE vw_pub_subcategorie; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.vw_pub_subcategorie TO syntra_web;
GRANT SELECT ON TABLE public.vw_pub_subcategorie TO syntra_medewerker;
GRANT SELECT ON TABLE public.vw_pub_subcategorie TO syntra_lesgever;
GRANT ALL ON TABLE public.vw_pub_subcategorie TO syntra_admin;


--
-- PostgreSQL database dump complete
--

\unrestrict HERKB2g80SIo4zlcpesCJSrnKCDa7jX9ZrNCSQlViVkNGZkcgolTJPMYQ2YZGaZ

