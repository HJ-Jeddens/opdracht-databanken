/* =====================================================================
   03_functies_en_triggers.sql

   Functies (fn_...) geven een waarde terug en gebruik je in een SELECT.
   Triggers houden gegevens automatisch consistent bij een INSERT of
   UPDATE.

   De views in 04_views.sql gebruiken deze functies, dus dit script moet
   eerst uitgevoerd worden.
   ===================================================================== */


/* ---------------------------------------------------------------------
   1. FUNCTIES
   --------------------------------------------------------------------- */

-- 1.1 Hoeveel cursisten zitten er in een periode?
-- Geannuleerde inschrijvingen tellen niet mee.
CREATE OR REPLACE FUNCTION fn_aantal_ingeschreven(p_periode_id INT)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
    v_aantal INT;
BEGIN
    SELECT COUNT(*)
    INTO   v_aantal
    FROM   inschrijving
    WHERE  periode_id = p_periode_id
      AND  status IN ('aangevraagd', 'bevestigd', 'afgewerkt');

    RETURN v_aantal;
END;
$$;

COMMENT ON FUNCTION fn_aantal_ingeschreven(INT) IS 'Aantal actieve inschrijvingen voor een opleidingsperiode.';


-- 1.2 Hoeveel plaatsen zijn er nog vrij?
CREATE OR REPLACE FUNCTION fn_vrije_plaatsen(p_periode_id INT)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
    v_max  INT;
    v_bezet INT;
BEGIN
    SELECT max_cursisten
    INTO   v_max
    FROM   opleidingsperiode
    WHERE  periode_id = p_periode_id;

    IF v_max IS NULL THEN
        RETURN NULL;                 -- periode bestaat niet
    END IF;

    v_bezet := fn_aantal_ingeschreven(p_periode_id);

    -- GREATEST voorkomt een negatief getal als de capaciteit ooit
    -- handmatig verlaagd zou worden.
    RETURN GREATEST(0, v_max - v_bezet);
END;
$$;


-- 1.3 Hoeveel moet er nog betaald worden voor een inschrijving?
CREATE OR REPLACE FUNCTION fn_openstaand_saldo(p_inschrijving_id INT)
RETURNS DECIMAL(8,2)
LANGUAGE plpgsql
AS $$
DECLARE
    v_te_betalen DECIMAL(8,2);
    v_betaald    DECIMAL(8,2);
BEGIN
    SELECT te_betalen
    INTO   v_te_betalen
    FROM   inschrijving
    WHERE  inschrijving_id = p_inschrijving_id;

    IF v_te_betalen IS NULL THEN
        RETURN NULL;
    END IF;

    -- COALESCE: zonder betalingen geeft SUM() NULL terug, geen 0.
    SELECT COALESCE(SUM(bedrag), 0)
    INTO   v_betaald
    FROM   betaling
    WHERE  inschrijving_id = p_inschrijving_id;

    RETURN v_te_betalen - v_betaald;
END;
$$;


-- 1.4 Is een cursist geslaagd voor een module?
-- Een vrijstelling telt als geslaagd. Anders volstaat een geslaagde poging.
CREATE OR REPLACE FUNCTION fn_module_geslaagd(p_inschrijving_module_id INT)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
DECLARE
    v_vrijstelling BOOLEAN;
    v_beste_score  DECIMAL(5,2);
BEGIN
    SELECT vrijstelling
    INTO   v_vrijstelling
    FROM   inschrijving_module
    WHERE  inschrijving_module_id = p_inschrijving_module_id;

    IF v_vrijstelling IS NULL THEN
        RETURN NULL;
    ELSIF v_vrijstelling THEN
        RETURN TRUE;
    END IF;

    SELECT MAX(score)
    INTO   v_beste_score
    FROM   evaluatie
    WHERE  inschrijving_module_id = p_inschrijving_module_id;

    RETURN COALESCE(v_beste_score >= 50, FALSE);
END;
$$;


-- 1.5 Leeftijd in jaren
CREATE OR REPLACE FUNCTION fn_leeftijd(p_geboortedatum DATE)
RETURNS INT
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_geboortedatum IS NULL THEN
        RETURN NULL;
    END IF;

    RETURN EXTRACT(YEAR FROM AGE(CURRENT_DATE, p_geboortedatum));
END;
$$;


/* ---------------------------------------------------------------------
   2. TRIGGERS
   --------------------------------------------------------------------- */

-- 2.1 gewijzigd_op automatisch bijhouden
-- Een trigger is betrouwbaarder dan dit in de applicatie doen: ook een
-- rechtstreekse UPDATE in pgAdmin wordt zo correct gelogd.
CREATE OR REPLACE FUNCTION fn_zet_gewijzigd_op()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.gewijzigd_op := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_categorie_gewijzigd    ON categorie;
DROP TRIGGER IF EXISTS trg_subcategorie_gewijzigd ON subcategorie;
DROP TRIGGER IF EXISTS trg_opleiding_gewijzigd    ON opleiding;
DROP TRIGGER IF EXISTS trg_periode_gewijzigd      ON opleidingsperiode;
DROP TRIGGER IF EXISTS trg_persoon_gewijzigd      ON persoon;

CREATE TRIGGER trg_categorie_gewijzigd
    BEFORE UPDATE ON categorie
    FOR EACH ROW EXECUTE FUNCTION fn_zet_gewijzigd_op();

CREATE TRIGGER trg_subcategorie_gewijzigd
    BEFORE UPDATE ON subcategorie
    FOR EACH ROW EXECUTE FUNCTION fn_zet_gewijzigd_op();

CREATE TRIGGER trg_opleiding_gewijzigd
    BEFORE UPDATE ON opleiding
    FOR EACH ROW EXECUTE FUNCTION fn_zet_gewijzigd_op();

CREATE TRIGGER trg_periode_gewijzigd
    BEFORE UPDATE ON opleidingsperiode
    FOR EACH ROW EXECUTE FUNCTION fn_zet_gewijzigd_op();

CREATE TRIGGER trg_persoon_gewijzigd
    BEFORE UPDATE ON persoon
    FOR EACH ROW EXECUTE FUNCTION fn_zet_gewijzigd_op();


-- 2.2 Statuswijzigingen van een inschrijving loggen
-- Handig om achteraf te kunnen aantonen wanneer iemand geannuleerd heeft.
CREATE OR REPLACE FUNCTION fn_log_inschrijving_status()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO inschrijving_log (inschrijving_id, oude_status, nieuwe_status)
        VALUES (NEW.inschrijving_id, NULL, NEW.status);

    ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO inschrijving_log (inschrijving_id, oude_status, nieuwe_status)
        VALUES (NEW.inschrijving_id, OLD.status, NEW.status);
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_inschrijving_log ON inschrijving;

CREATE TRIGGER trg_inschrijving_log
    AFTER INSERT OR UPDATE ON inschrijving
    FOR EACH ROW EXECUTE FUNCTION fn_log_inschrijving_status();


/* ---------------------------------------------------------------------
   CONTROLE
   --------------------------------------------------------------------- */
SELECT routine_name AS functie
FROM   information_schema.routines
WHERE  routine_schema = 'public'
  AND  routine_type   = 'FUNCTION'
ORDER  BY routine_name;

SELECT trigger_name AS trigger, event_object_table AS tabel, event_manipulation AS gebeurtenis
FROM   information_schema.triggers
WHERE  trigger_schema = 'public'
ORDER  BY event_object_table, trigger_name;
