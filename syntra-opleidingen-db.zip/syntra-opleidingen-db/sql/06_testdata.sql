/* =====================================================================
   06_testdata.sql

   De catalogusgegevens (categorieen, subcategorieen, opleidingen en
   modules) komen van syntra-mvl.be, geraadpleegd in augustus 2026.

   ALLE PERSONEN, INSCHRIJVINGEN, RESULTATEN EN BETALINGEN ZIJN
   VERZONNEN. Ook de rijksregisternummers, IBAN's en wachtwoorden zijn
   fictief en horen bij niemand.

   Dit script gebruikt gewone INSERT-statements. De stored procedures
   worden apart uitgetest in 08_testscript.sql.
   ===================================================================== */

-- Alles leegmaken zodat dit script herhaalbaar is.
-- TRUNCATE ... CASCADE ruimt ook de tabellen op die ernaar verwijzen.
-- RESTART IDENTITY zet de tellers van de id-kolommen terug op 1.
-- inschrijving_log staat er expliciet bij: die tabel heeft geen foreign
-- key naar inschrijving (een logboek moet blijven bestaan als een rij
-- verdwijnt), dus CASCADE ruimt hem niet mee op.
TRUNCATE TABLE persoon, categorie, campus, opleidingsvorm, niveau, inschrijving_log
    RESTART IDENTITY CASCADE;


/* ---------------------------------------------------------------------
   1. REFERENTIEGEGEVENS
   --------------------------------------------------------------------- */

INSERT INTO opleidingsvorm (vorm_code, omschrijving, volgorde) VALUES
    ('avond',       'Avondopleiding',                 1),
    ('dag',         'Dagopleiding',                   2),
    ('voltijds',    'Voltijdse dagopleiding',         3),
    ('etraject',    'E-traject',                      4),
    ('bijscholing', 'Bijscholingen en specialisaties', 5);

INSERT INTO niveau (niveau_code, omschrijving, volgorde) VALUES
    ('beginner',  'Beginner',  1),
    ('gevorderd', 'Gevorderd', 2);

INSERT INTO campus (naam, adres, postcode, gemeente, telefoon, email) VALUES
    ('Campus Gent',         'Autoweg-Zuid 3',   '9051', 'Gent',         '+32 9 265 15 00', 'gent@syntra-mvl.be'),
    ('Campus Sint-Niklaas', 'Hogekouter 1',     '9100', 'Sint-Niklaas', '+32 3 780 55 00', 'sintniklaas@syntra-mvl.be'),
    ('Campus Aalst',        'Wijngaardveld 10', '9300', 'Aalst',        '+32 53 76 91 00', 'aalst@syntra-mvl.be');


/* ---------------------------------------------------------------------
   2. CATEGORIEEN
   Bron: https://syntra-mvl.be/nl/opleidingen
   --------------------------------------------------------------------- */

INSERT INTO categorie (naam, slug, omschrijving, afbeelding_url, volgorde) VALUES
    ('Ambachten & interieur',                'ambachten-interieur',                NULL, NULL,  1),
    ('Beauty & Wellness',                    'beauty-wellness',                    NULL, NULL,  2),
    ('Bouw en energie',                      'bouw-en-energie',                    NULL, NULL,  3),
    ('Dieren',                               'dieren',                             NULL, NULL,  4),
    ('Financien, verzekeringen en vastgoed', 'financien-verzekeringen-en-vastgoed', NULL, NULL,  5),
    ('Grafisch, IT en media',                'grafisch-it-en-media',
     'Volledig mee zijn in de laatste digitale trends? Dan is een opleiding in IT, media of graphic design jouw volgende stop.',
     'https://syntra-mvl.be/wp-content/uploads/2024/09/SyntraMVL_website_sectorbeelden_400x245_GrafischeMedia.jpg', 6),
    ('Groen & tuin',                         'groen-tuin',                         NULL, NULL,  7),
    ('Horeca, dranken en voeding',           'horeca-dranken-en-voeding',          NULL, NULL,  8),
    ('HR, management en ontwikkeling',       'hr-management-en-ontwikkeling',      NULL, NULL,  9),
    ('Marketing en sales',                   'marketing-en-sales',                 NULL, NULL, 10),
    ('Microsoft Office',                     'microsoft-office',                   NULL, NULL, 11),
    ('Ondernemerschap',                      'ondernemerschap',                    NULL, NULL, 12),
    ('Sport en zorg',                        'sport-en-zorg',                      NULL, NULL, 13),
    ('Transport & logistiek',                'transport-logistiek',                NULL, NULL, 14),
    ('Veiligheid & preventie',               'veiligheid-preventie',               NULL, NULL, 15),
    ('Voertuigen & metaal',                  'voertuigen-metaal',                  NULL, NULL, 16);


/* ---------------------------------------------------------------------
   3. SUBCATEGORIEEN
   Bron: https://syntra-mvl.be/nl/opleidingen/grafisch-it-en-media
   --------------------------------------------------------------------- */

INSERT INTO subcategorie (categorie_id, naam, slug, omschrijving, afbeelding_url, volgorde)
SELECT c.categorie_id, s.naam, s.slug, s.omschrijving, s.afbeelding_url, s.volgorde
FROM   categorie c
CROSS JOIN (VALUES
    ('Data & software development', 'data-software-development',
     'Geen enkele sector biedt zoveel mogelijkheden en toekomstperspectief als de IT-sector. Ontwikkel je vaardigheden als data-analist, software-ontwikkelaar of IT-consultant.',
     'https://syntra-mvl.be/wp-content/uploads/2023/04/card__data.jpeg', 1::SMALLINT),
    ('Foto & video',          'foto-video',           NULL, NULL, 2),
    ('Gaming en animatie',    'gaming-en-animatie',   NULL, NULL, 3),
    ('Grafische vormgeving',  'grafische-vormgeving', NULL, NULL, 4),
    ('Hardware & telecom',    'hardware-telecom',     NULL, NULL, 5),
    ('Media',                 'media',                NULL, NULL, 6),
    ('Podiumtechnieken',      'podiumtechnieken',     NULL, NULL, 7)
) AS s(naam, slug, omschrijving, afbeelding_url, volgorde)
WHERE c.slug = 'grafisch-it-en-media';

-- De overzichtspagina van Data & software development toont ook
-- cybersecurity-opleidingen. Volgens hun eigen URL horen die onder
-- Veiligheid & preventie, dus daar maken we de subcategorie voor aan.
INSERT INTO subcategorie (categorie_id, naam, slug, volgorde)
SELECT categorie_id, 'Security', 'security', 1
FROM   categorie
WHERE  slug = 'veiligheid-preventie';


/* ---------------------------------------------------------------------
   4. OPLEIDINGEN
   Bron: /nl/opleidingen/grafisch-it-en-media/data-software-development
   Elke opleiding staat in de subcategorie die haar eigen URL aangeeft.
   --------------------------------------------------------------------- */

INSERT INTO opleiding (subcategorie_id, vorm_code, niveau_code, naam, slug,
                       korte_omschrijving, duur_in_jaren, ai_geintegreerd, nieuw)
SELECT s.subcategorie_id, o.vorm, o.niveau, o.naam, o.slug, o.kort,
       o.duur, o.ai, o.nieuw
FROM (VALUES
    -- subcategorie_slug, vorm, niveau, naam, slug, korte omschrijving, duur, ai, nieuw
    ('data-software-development', 'avond', 'beginner', 'Businessanalist',
     'business-analist-bedrijfsanalist-ict',
     'Leer bedrijfsprocessen analyseren en vertalen naar heldere IT-vereisten.', 1.0, FALSE, FALSE),
    ('data-software-development', 'avond', 'beginner', 'Data-analist', 'data-analist',
     'Data verzamelen, analyseren en visualiseren om betere beslissingen te ondersteunen.', 1.0, FALSE, FALSE),
    ('data-software-development', 'avond', 'beginner', 'Python data developer', 'python-data-developer',
     'Een Python data developer gebruikt Python om dataprocessen en systemen te ontwikkelen, beheren en optimaliseren.', 1.0, TRUE, FALSE),
    ('data-software-development', 'bijscholing', 'beginner', 'Game engine fundamentals',
     'game-engine-fundamentals',
     'Maak kennis met de bouwstenen van een moderne game engine.', 0.5, FALSE, TRUE),
    ('data-software-development', 'avond', 'beginner', 'Software developer Python & AI assistance',
     'software-developer-python-ai',
     'Ontwikkel software in Python en leer AI-assistenten inzetten in je ontwikkelproces.', 1.0, TRUE, TRUE),
    ('data-software-development', 'avond', 'beginner', 'Software developer Full stack foundations & AI assistance',
     'software-developer-full-stack-foundations-ai',
     'De fundamenten van full stack development, ondersteund door AI.', 1.0, TRUE, TRUE),
    ('data-software-development', 'avond', 'beginner', 'IT fundamentals', 'it-fundamentals',
     'De basisbegrippen van IT voor wie zonder voorkennis start.', 0.5, FALSE, TRUE),
    ('data-software-development', 'etraject', 'gevorderd', 'Data Steward', 'data-steward-online',
     'Bewaak de kwaliteit, herkomst en governance van data in je organisatie.', 1.0, FALSE, TRUE),
    ('data-software-development', 'etraject', 'gevorderd', 'Local large language model specialist',
     'local-large-language-model-specialist-english-online',
     'Zet lokaal draaiende large language models op en beheer ze.', 1.0, TRUE, TRUE),
    ('data-software-development', 'avond', 'gevorderd', 'Cybersecurity analist', 'cybersecurity-analist',
     'Detecteer, analyseer en rapporteer securityincidenten.', 1.0, FALSE, FALSE),
    ('data-software-development', 'dag', 'gevorderd', 'Cybersecurity specialist',
     'cybersecurity-specialist-engineer-en-analist',
     'Het volledige traject van cybersecurity engineer en analist.', 1.0, FALSE, FALSE),
    -- opleidingen uit andere subcategorieen die op dezelfde filterpagina staan
    ('grafische-vormgeving', 'avond', 'beginner', 'UX Designer',
     'user-experience-designer-ux-designer',
     'Ontwerp digitale producten die mensen graag gebruiken.', 1.0, TRUE, FALSE),
    ('grafische-vormgeving', 'etraject', 'beginner', 'UX Designer (online)', 'ux-designer-online',
     'Dezelfde UX-competenties, volledig op eigen tempo.', 1.0, TRUE, TRUE),
    ('hardware-telecom', 'avond', 'beginner', 'Netwerkbeheerder', 'netwerkbeheerder',
     'Bouw, beheer en beveilig bedrijfsnetwerken.', 1.0, FALSE, FALSE),
    ('hardware-telecom', 'voltijds', 'beginner', 'Netwerkbeheerder (voltijds)',
     'voltijdse-dagopleiding-netwerkbeheerder',
     'Netwerkbeheerder in een voltijds dagtraject.', 1.0, FALSE, FALSE),
    ('security', 'avond', 'gevorderd', 'Cybersecurity engineer', 'cybersecurity-engineer',
     'Beveilig infrastructuur en applicaties tegen aanvallen.', 1.0, FALSE, FALSE),
    ('security', 'dag', 'beginner', 'Cybersecurity administrator', 'cybersecurity-administrator',
     'De operationele kant van cybersecurity.', 1.0, FALSE, TRUE)
) AS o(sub_slug, vorm, niveau, naam, slug, kort, duur, ai, nieuw)
JOIN subcategorie s ON s.slug = o.sub_slug;

-- De uitgebreide teksten van de opleiding uit de opdracht.
UPDATE opleiding
SET    lange_omschrijving =
         'Je leert eerst programmeren in Python, waarbij je ook leert hoe AI wordt ingezet om code te verbeteren '
      || 'en problemen op te lossen. Daarna leer je het opzetten, onderhouden en bevragen van databanken. In de '
      || 'tweede helft wordt de opgedane kennis ingezet op het verzamelen, analyseren en visualiseren van data '
      || 'met NumPy, Pandas en Matplotlib.',
       doelgroep =
         'Iedereen die een professionele carriere als Python data developer wil uitbouwen. Voorkennis is niet '
      || 'vereist, een solide basis Engels en logisch redeneren wel. Je bent minstens 18 jaar in het kalenderjaar '
      || 'waarin de opleiding start.'
WHERE  slug = 'python-data-developer';


/* ---------------------------------------------------------------------
   5. MODULES
   Bron: de programmapagina van Python data developer.
   Dit is de opleiding "python-developer" uit de opdracht.
   --------------------------------------------------------------------- */

INSERT INTO module (opleiding_id, code, naam, omschrijving, aantal_sessies,
                    vrijstelbaar, eindproef, volgorde)
SELECT o.opleiding_id, m.code, m.naam, m.omschrijving, m.sessies,
       m.vrijstelbaar, m.eindproef, m.volgorde
FROM   opleiding o
CROSS JOIN (VALUES
    ('PY-BASIS', 'Leren programmeren in Python',
     'Kennismaking met de basisprincipes van programmeren en ontwikkeling van logisch inzicht om eenvoudige Python-programma''s op te bouwen.',
     16::SMALLINT, TRUE, FALSE, 1::SMALLINT),
    ('PY-OO', 'OO Programmeren in Python',
     'Verdieping in objectgeorienteerd programmeren met aandacht voor het structureren van software via klassen die moeiteloos samenwerken.',
     16, TRUE, FALSE, 2),
    ('PY-DB', 'Databanken',
     'De essentiele vaardigheden voor het ontwerpen en beheren van databanken en het schrijven van efficiente SQL-query''s voor correcte en veilige dataverwerking.',
     12, TRUE, FALSE, 3),
    ('PY-NUMPY', 'Python for data science: NumPy',
     'Werken met NumPy voor het structureren van data en het uitvoeren van performante berekeningen op datasets.',
     7, TRUE, FALSE, 4),
    ('PY-PANDAS', 'Python for data science: Pandas',
     'Toepassen van Pandas voor het analyseren, manipuleren en structureren van data binnen een data science context.',
     8, FALSE, FALSE, 5),
    ('PY-CLEAN', 'Data exploration & cleaning with Python',
     'Inzicht verwerven in het opschonen, verkennen en visualiseren van data om tot betrouwbare analyses te komen.',
     8, FALSE, FALSE, 6),
    ('PY-EP', 'EP Python data developer',
     'Integratie van alle opgedane kennis in een praktijkgericht project met focus op data-analyse, verwerking en presentatie.',
     6, FALSE, TRUE, 7)
) AS m(code, naam, omschrijving, sessies, vrijstelbaar, eindproef, volgorde)
WHERE o.slug = 'python-data-developer';

-- Een tweede opleiding met modules, zodat de structuur ook getest wordt
-- met meer dan een opleiding.
INSERT INTO module (opleiding_id, code, naam, aantal_sessies, vrijstelbaar, eindproef, volgorde)
SELECT o.opleiding_id, m.code, m.naam, m.sessies, m.vrijstelbaar, m.eindproef, m.volgorde
FROM   opleiding o
CROSS JOIN (VALUES
    ('DA-STAT', 'Statistiek voor data-analisten', 10::SMALLINT, TRUE,  FALSE, 1::SMALLINT),
    ('DA-SQL',  'SQL en datamodellering',         12,           TRUE,  FALSE, 2),
    ('DA-VIZ',  'Datavisualisatie met Power BI',   8,           FALSE, FALSE, 3),
    ('DA-EP',   'EP Data-analist',                 6,           FALSE, TRUE,  4)
) AS m(code, naam, sessies, vrijstelbaar, eindproef, volgorde)
WHERE o.slug = 'data-analist';


/* ---------------------------------------------------------------------
   6. DE TWEE OPLEIDINGSPERIODES VAN PYTHON DATA DEVELOPER
   --------------------------------------------------------------------- */

INSERT INTO opleidingsperiode (opleiding_id, campus_id, code, academiejaar,
                               startdatum, einddatum, dagdeel, prijs,
                               max_cursisten, inschrijven_tot, status, lessenrooster_url)
SELECT o.opleiding_id, c.campus_id, p.code, p.jaar, p.start, p.eind,
       'avond', p.prijs, p.max_cur, p.start - 1, 'open', p.rooster
FROM   opleiding o
JOIN   campus c ON c.naam = 'Campus Gent'
CROSS JOIN (VALUES
    ('PDD-2026-GENT', '2026-2027', DATE '2026-09-14', DATE '2027-06-25', 1010.00, 18::SMALLINT,
     'https://mijn.syntra-mvl.be/Lessenrooster?cursus=PDD-2026-GENT'),
    ('PDD-2027-GENT', '2027-2028', DATE '2027-09-13', DATE '2028-06-23', 1045.00, 18,
     'https://mijn.syntra-mvl.be/Lessenrooster?cursus=PDD-2027-GENT')
) AS p(code, jaar, start, eind, prijs, max_cur, rooster)
WHERE o.slug = 'python-data-developer';

-- Een periode voor de tweede opleiding.
INSERT INTO opleidingsperiode (opleiding_id, campus_id, code, academiejaar,
                               startdatum, einddatum, dagdeel, prijs,
                               max_cursisten, inschrijven_tot, status)
SELECT o.opleiding_id, c.campus_id, 'DA-2026-GENT', '2026-2027',
       DATE '2026-09-15', DATE '2027-06-24', 'avond', 1150.00, 16,
       DATE '2026-09-14', 'open'
FROM   opleiding o
JOIN   campus c ON c.naam = 'Campus Gent'
WHERE  o.slug = 'data-analist';


/* ---------------------------------------------------------------------
   7. MODULES INPLANNEN BINNEN DE PERIODES
   Elke periode bevat ALLE modules van de opleiding, met een eigen
   planning. Dat is precies waarvoor de koppeltabel periode_module dient.
   --------------------------------------------------------------------- */

INSERT INTO periode_module (periode_id, module_id, volgorde, startdatum, einddatum)
SELECT p.periode_id, m.module_id, m.volgorde, p.startdatum, p.einddatum
FROM   opleidingsperiode p
JOIN   module m ON m.opleiding_id = p.opleiding_id;

-- Academiejaar 2026-2027: de modules volgen elkaar op.
UPDATE periode_module pm
SET    startdatum = d.start,
       einddatum  = d.eind
FROM   (VALUES
    ('PY-BASIS',  DATE '2026-09-14', DATE '2026-11-16'),
    ('PY-OO',     DATE '2026-11-17', DATE '2027-01-26'),
    ('PY-DB',     DATE '2027-01-27', DATE '2027-03-09'),
    ('PY-NUMPY',  DATE '2027-03-10', DATE '2027-04-13'),
    ('PY-PANDAS', DATE '2027-04-14', DATE '2027-05-18'),
    ('PY-CLEAN',  DATE '2027-05-19', DATE '2027-06-08'),
    ('PY-EP',     DATE '2027-06-09', DATE '2027-06-25')
) AS d(code, start, eind)
JOIN   module m ON m.code = d.code
WHERE  pm.module_id  = m.module_id
  AND  pm.periode_id = (SELECT periode_id FROM opleidingsperiode WHERE code = 'PDD-2026-GENT');

-- Academiejaar 2027-2028: dezelfde modules, een jaar later.
UPDATE periode_module pm
SET    startdatum = d.start,
       einddatum  = d.eind
FROM   (VALUES
    ('PY-BASIS',  DATE '2027-09-13', DATE '2027-11-15'),
    ('PY-OO',     DATE '2027-11-16', DATE '2028-01-25'),
    ('PY-DB',     DATE '2028-01-26', DATE '2028-03-07'),
    ('PY-NUMPY',  DATE '2028-03-08', DATE '2028-04-11'),
    ('PY-PANDAS', DATE '2028-04-12', DATE '2028-05-16'),
    ('PY-CLEAN',  DATE '2028-05-17', DATE '2028-06-06'),
    ('PY-EP',     DATE '2028-06-07', DATE '2028-06-23')
) AS d(code, start, eind)
JOIN   module m ON m.code = d.code
WHERE  pm.module_id  = m.module_id
  AND  pm.periode_id = (SELECT periode_id FROM opleidingsperiode WHERE code = 'PDD-2027-GENT');


/* ---------------------------------------------------------------------
   8. LESGEVERS (verzonnen gegevens)
   --------------------------------------------------------------------- */

INSERT INTO persoon (voornaam, familienaam, email, telefoon) VALUES
    ('Sofie', 'Maes',       'sofie.maes@syntra-mvl.be',       '+32 476 22 33 44'),
    ('Wim',   'Segers',     'wim.segers@syntra-mvl.be',       '+32 475 11 22 33'),
    ('Karim', 'El Amrani',  'karim.elamrani@syntra-mvl.be',   '+32 477 33 44 55'),
    ('An',    'Peeters',    'an.peeters@syntra-mvl.be',       '+32 478 44 55 66'),
    ('Tom',   'De Smet',    'tom.desmet@syntra-mvl.be',       '+32 479 55 66 77');

INSERT INTO lesgever (lesgever_id, lesgevernummer, publieke_bio,
                      ondernemingsnummer, uurtarief, iban, in_dienst_sinds)
SELECT p.persoon_id,
       'L' || LPAD(p.persoon_id::TEXT, 4, '0'),
       l.bio, l.onr, l.tarief, l.iban, l.sinds
FROM (VALUES
    ('sofie.maes@syntra-mvl.be',
     'Software engineer en Python-trainer. Werkt dagelijks met backend-API''s en automatisatie.',
     'BE0234567891', 72.00, 'BE71096123456769', DATE '2018-01-15'),
    ('wim.segers@syntra-mvl.be',
     'Databankarchitect met twintig jaar ervaring in industriele dataplatformen. Geeft les over relationele modellering en SQL.',
     'BE0123456789', 78.50, 'BE68539007547034', DATE '2015-09-01'),
    ('karim.elamrani@syntra-mvl.be',
     'Data scientist. Begeleidt cursisten in NumPy, Pandas en visualisatie.',
     'BE0345678912', 80.00, 'BE62510007547061', DATE '2020-09-01'),
    ('an.peeters@syntra-mvl.be',
     'Analytics consultant met een achtergrond in bedrijfskunde.',
     'BE0456789123', 69.00, 'BE43068999999501', DATE '2022-02-01'),
    ('tom.desmet@syntra-mvl.be',
     'Projectcoach voor eindwerken en praktijkprojecten.',
     'BE0567891234', 65.00, 'BE72000000001616', DATE '2019-09-01')
) AS l(email, bio, onr, tarief, iban, sinds)
JOIN persoon p ON p.email = l.email;

-- Wie geeft welke module in welke periode?
INSERT INTO periode_module_lesgever (periode_module_id, lesgever_id, rol)
SELECT pm.periode_module_id, per.persoon_id, t.rol
FROM (VALUES
    ('PDD-2026-GENT', 'PY-BASIS',  'sofie.maes@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2026-GENT', 'PY-OO',     'sofie.maes@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2026-GENT', 'PY-DB',     'wim.segers@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2026-GENT', 'PY-NUMPY',  'karim.elamrani@syntra-mvl.be', 'hoofddocent'),
    ('PDD-2026-GENT', 'PY-PANDAS', 'karim.elamrani@syntra-mvl.be', 'hoofddocent'),
    ('PDD-2026-GENT', 'PY-CLEAN',  'an.peeters@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2026-GENT', 'PY-EP',     'tom.desmet@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2026-GENT', 'PY-EP',     'karim.elamrani@syntra-mvl.be', 'co-docent'),
    ('PDD-2027-GENT', 'PY-BASIS',  'sofie.maes@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2027-GENT', 'PY-OO',     'sofie.maes@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2027-GENT', 'PY-DB',     'wim.segers@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2027-GENT', 'PY-NUMPY',  'karim.elamrani@syntra-mvl.be', 'hoofddocent'),
    ('PDD-2027-GENT', 'PY-PANDAS', 'an.peeters@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2027-GENT', 'PY-CLEAN',  'an.peeters@syntra-mvl.be',     'hoofddocent'),
    ('PDD-2027-GENT', 'PY-EP',     'tom.desmet@syntra-mvl.be',     'hoofddocent')
) AS t(periode_code, module_code, email, rol)
JOIN opleidingsperiode p  ON p.code = t.periode_code
JOIN module            m  ON m.code = t.module_code AND m.opleiding_id = p.opleiding_id
JOIN periode_module    pm ON pm.periode_id = p.periode_id AND pm.module_id = m.module_id
JOIN persoon           per ON per.email = t.email;


/* ---------------------------------------------------------------------
   9. CURSISTEN (verzonnen gegevens)
   Het wachtwoord wordt versleuteld bewaard met crypt() uit pgcrypto.
   --------------------------------------------------------------------- */

INSERT INTO persoon (voornaam, familienaam, email, telefoon, geboortedatum,
                     rijksregisternr, adres, postcode, gemeente) VALUES
    ('Ella',    'Janssens',  'ella.janssens@example.be',    '+32 470 10 20 30', DATE '1995-03-12', '95031212345', 'Kerkstraat 12',    '9000', 'Gent'),
    ('Milan',   'Vermeulen', 'milan.vermeulen@example.be',  '+32 471 11 21 31', DATE '1990-07-24', '90072423456', 'Dorpsplein 4',     '9100', 'Sint-Niklaas'),
    ('Fatima',  'Boujida',   'fatima.boujida@example.be',   '+32 472 12 22 32', DATE '1998-11-02', '98110234567', 'Molenstraat 77',   '9300', 'Aalst'),
    ('Jonas',   'De Clercq', 'jonas.declercq@example.be',   '+32 473 13 23 33', DATE '1987-01-30', '87013045678', 'Stationsstraat 9', '9050', 'Gentbrugge'),
    ('Amber',   'Willems',   'amber.willems@example.be',    '+32 474 14 24 34', DATE '2000-05-18', '00051856789', 'Lindelaan 23',     '9040', 'Sint-Amandsberg'),
    ('Kobe',    'Verhaeghe', 'kobe.verhaeghe@example.be',   '+32 475 15 25 35', DATE '1993-09-09', '93090967891', 'Veldstraat 101',   '9000', 'Gent'),
    ('Nina',    'Dhondt',    'nina.dhondt@example.be',      '+32 476 16 26 36', DATE '1996-12-21', '96122178912', 'Meersstraat 8',    '9051', 'Sint-Denijs-Westrem'),
    ('Yassine', 'Cherkaoui', 'yassine.cherkaoui@example.be','+32 477 17 27 37', DATE '1992-02-14', '92021489123', 'Nieuwstraat 15',   '9200', 'Dendermonde'),
    ('Lore',    'Van Damme', 'lore.vandamme@example.be',    '+32 478 18 28 38', DATE '1999-08-05', '99080591234', 'Bergstraat 32',    '9700', 'Oudenaarde'),
    ('Bram',    'Coppens',   'bram.coppens@example.be',     '+32 479 19 29 39', DATE '1985-04-27', '85042792345', 'Zandstraat 56',    '9250', 'Waasmunster'),
    ('Iris',    'Lemmens',   'iris.lemmens@example.be',     '+32 470 20 30 40', DATE '1997-06-11', '97061193456', 'Parklaan 3',       '9000', 'Gent'),
    ('Simon',   'Roelandt',  'simon.roelandt@example.be',   '+32 471 21 31 41', DATE '1991-10-19', '91101994567', 'Beukenlaan 44',    '9120', 'Beveren');

INSERT INTO cursist (cursist_id, cursistnummer, wachtwoord_hash, hoogste_diploma,
                     opleidingscheques, kmo_portefeuille, interne_notitie)
SELECT p.persoon_id,
       'C' || LPAD(p.persoon_id::TEXT, 5, '0'),
       crypt(c.wachtwoord, gen_salt('bf')),
       c.diploma, c.cheques, c.kmo, c.notitie
FROM (VALUES
    ('ella.janssens@example.be',     'Bachelor communicatiewetenschappen', TRUE,  FALSE, NULL, 'Test1234!'),
    ('milan.vermeulen@example.be',   'Bachelor bedrijfsmanagement',        FALSE, TRUE,
     'Zelfstandige - factuur op ondernemingsnummer.', 'Test1234!'),
    ('fatima.boujida@example.be',    'Master biomedische wetenschappen',   FALSE, FALSE, NULL, 'Test1234!'),
    ('jonas.declercq@example.be',    'Secundair onderwijs',                TRUE,  FALSE, NULL, 'Test1234!'),
    ('amber.willems@example.be',     'Bachelor toegepaste informatica',    FALSE, FALSE, NULL, 'Test1234!'),
    ('kobe.verhaeghe@example.be',    'Bachelor elektromechanica',          FALSE, FALSE, NULL, 'Test1234!'),
    ('nina.dhondt@example.be',       'Bachelor handelswetenschappen',      FALSE, FALSE, NULL, 'Test1234!'),
    ('yassine.cherkaoui@example.be', 'Bachelor accountancy',               FALSE, FALSE, NULL, 'Test1234!'),
    ('lore.vandamme@example.be',     'Bachelor grafische vormgeving',      FALSE, FALSE, NULL, 'Test1234!'),
    ('bram.coppens@example.be',      'Secundair onderwijs',                FALSE, FALSE, NULL, 'Test1234!'),
    ('iris.lemmens@example.be',      'Master kunstwetenschappen',          FALSE, FALSE, NULL, 'Test1234!'),
    ('simon.roelandt@example.be',    'Bachelor logistiek',                 FALSE, FALSE, NULL, 'Test1234!')
) AS c(email, diploma, cheques, kmo, notitie, wachtwoord)
JOIN persoon p ON p.email = c.email;


/* ---------------------------------------------------------------------
   10. INSCHRIJVINGEN
   --------------------------------------------------------------------- */

INSERT INTO inschrijving (cursist_id, periode_id, status, te_betalen, korting, opmerking)
SELECT p.persoon_id, per.periode_id, i.status, i.bedrag, i.korting, i.opmerking
FROM (VALUES
    ('ella.janssens@example.be',     'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('milan.vermeulen@example.be',   'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('fatima.boujida@example.be',    'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('jonas.declercq@example.be',    'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('amber.willems@example.be',     'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('kobe.verhaeghe@example.be',    'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('nina.dhondt@example.be',       'PDD-2026-GENT', 'bevestigd',   1010.00, NULL, NULL),
    ('yassine.cherkaoui@example.be', 'PDD-2026-GENT', 'aangevraagd', 1010.00, NULL, 'Wacht op goedkeuring werkgever'),
    ('lore.vandamme@example.be',     'PDD-2026-GENT', 'geannuleerd', 1010.00, NULL, 'Cursist heeft afgezegd wegens verhuis.'),
    ('bram.coppens@example.be',      'PDD-2027-GENT', 'bevestigd',   1045.00, NULL, NULL),
    ('iris.lemmens@example.be',      'PDD-2027-GENT', 'aangevraagd',  945.00, 'Kortingsactie infoavond', NULL),
    ('simon.roelandt@example.be',    'PDD-2027-GENT', 'bevestigd',   1045.00, NULL, 'Wenst gespreide betaling'),
    ('nina.dhondt@example.be',       'DA-2026-GENT',  'bevestigd',   1150.00, NULL, NULL),
    ('kobe.verhaeghe@example.be',    'DA-2026-GENT',  'aangevraagd', 1150.00, NULL, NULL)
) AS i(email, periode_code, status, bedrag, korting, opmerking)
JOIN persoon           p   ON p.email  = i.email
JOIN opleidingsperiode per ON per.code = i.periode_code;

-- Elke cursist volgt alle modules van zijn periode.
INSERT INTO inschrijving_module (inschrijving_id, periode_module_id)
SELECT i.inschrijving_id, pm.periode_module_id
FROM   inschrijving   i
JOIN   periode_module pm ON pm.periode_id = i.periode_id;

-- Vrijstellingen
UPDATE inschrijving_module im
SET    vrijstelling           = TRUE,
       vrijstelling_motivatie = v.motivatie
FROM (VALUES
    ('amber.willems@example.be',   'PY-BASIS', 'Vrijstelling op basis van bachelor toegepaste informatica.'),
    ('amber.willems@example.be',   'PY-OO',    'Vrijstelling op basis van bachelor toegepaste informatica.'),
    ('milan.vermeulen@example.be', 'PY-DB',    'Eerder behaald moduleattest Databanken (2024).')
) AS v(email, module_code, motivatie)
JOIN persoon           p   ON p.email = v.email
JOIN inschrijving      i   ON i.cursist_id = p.persoon_id
JOIN opleidingsperiode per ON per.periode_id = i.periode_id AND per.code = 'PDD-2026-GENT'
JOIN periode_module    pm  ON pm.periode_id = i.periode_id
JOIN module            m   ON m.module_id = pm.module_id AND m.code = v.module_code
WHERE im.inschrijving_id   = i.inschrijving_id
  AND im.periode_module_id = pm.periode_module_id;


/* ---------------------------------------------------------------------
   11. EVALUATIES
   De VALUES-lijst hieronder wordt gejoind met de tabellen om het juiste
   inschrijving_module_id te vinden. Zo hoeven er geen id's in het script
   te staan en blijft het herhaalbaar.
   --------------------------------------------------------------------- */

INSERT INTO evaluatie (inschrijving_module_id, evaluatiedatum, score, poging, feedback, lesgever_id)
SELECT im.inschrijving_module_id, e.datum, e.score, e.poging, e.feedback, lg.persoon_id
FROM (VALUES
    ('ella.janssens@example.be',     'PY-BASIS', 78.00, 1::SMALLINT, DATE '2026-11-16', 'Sterk logisch inzicht.',           'sofie.maes@syntra-mvl.be'),
    ('milan.vermeulen@example.be',   'PY-BASIS', 65.00, 1,           DATE '2026-11-16', 'Goede basis, oefen nog op loops.', 'sofie.maes@syntra-mvl.be'),
    ('fatima.boujida@example.be',    'PY-BASIS', 91.00, 1,           DATE '2026-11-16', 'Uitstekend.',                      'sofie.maes@syntra-mvl.be'),
    ('jonas.declercq@example.be',    'PY-BASIS', 44.00, 1,           DATE '2026-11-16', 'Onvoldoende - herkansing nodig.',  'sofie.maes@syntra-mvl.be'),
    ('jonas.declercq@example.be',    'PY-BASIS', 62.00, 2,           DATE '2026-12-14', 'Geslaagd na herkansing.',          'sofie.maes@syntra-mvl.be'),
    ('kobe.verhaeghe@example.be',    'PY-BASIS', 70.00, 1,           DATE '2026-11-16', NULL,                               'sofie.maes@syntra-mvl.be'),
    ('nina.dhondt@example.be',       'PY-BASIS', 83.00, 1,           DATE '2026-11-16', NULL,                               'sofie.maes@syntra-mvl.be'),
    ('yassine.cherkaoui@example.be', 'PY-BASIS', 55.00, 1,           DATE '2026-11-16', NULL,                               'sofie.maes@syntra-mvl.be'),
    ('ella.janssens@example.be',     'PY-DB',    88.00, 1,           DATE '2027-03-09', 'Correcte normalisatie.',           'wim.segers@syntra-mvl.be'),
    ('fatima.boujida@example.be',    'PY-DB',    74.00, 1,           DATE '2027-03-09', NULL,                               'wim.segers@syntra-mvl.be'),
    ('kobe.verhaeghe@example.be',    'PY-DB',    66.00, 1,           DATE '2027-03-09', NULL,                               'wim.segers@syntra-mvl.be')
) AS e(email, module_code, score, poging, datum, feedback, docent)
JOIN persoon             p   ON p.email = e.email
JOIN inschrijving        i   ON i.cursist_id = p.persoon_id
JOIN opleidingsperiode   per ON per.periode_id = i.periode_id AND per.code = 'PDD-2026-GENT'
JOIN inschrijving_module im  ON im.inschrijving_id = i.inschrijving_id
JOIN periode_module      pm  ON pm.periode_module_id = im.periode_module_id
JOIN module              m   ON m.module_id = pm.module_id AND m.code = e.module_code
JOIN persoon             lg  ON lg.email = e.docent;


/* ---------------------------------------------------------------------
   12. BETALINGEN
   --------------------------------------------------------------------- */

INSERT INTO betaling (inschrijving_id, bedrag, betaaldatum, methode, referentie)
SELECT i.inschrijving_id, b.bedrag, b.datum, b.methode, b.referentie
FROM (VALUES
    ('ella.janssens@example.be',     'PDD-2026-GENT', 1010.00, DATE '2026-08-20', 'overschrijving',   'OVS-2026-0001'),
    ('milan.vermeulen@example.be',   'PDD-2026-GENT', 1010.00, DATE '2026-08-22', 'kmo_portefeuille', 'KMO-2026-0002'),
    ('fatima.boujida@example.be',    'PDD-2026-GENT', 1010.00, DATE '2026-08-25', 'bancontact',       'BC-2026-0003'),
    ('jonas.declercq@example.be',    'PDD-2026-GENT',  500.00, DATE '2026-08-26', 'opleidingscheque', 'OPL-2026-0004'),
    ('amber.willems@example.be',     'PDD-2026-GENT', 1010.00, DATE '2026-08-27', 'overschrijving',   'OVS-2026-0005'),
    ('kobe.verhaeghe@example.be',    'PDD-2026-GENT',  336.67, DATE '2026-08-28', 'kredietkaart',     'KK-2026-0006'),
    ('nina.dhondt@example.be',       'PDD-2026-GENT', 1010.00, DATE '2026-09-01', 'overschrijving',   'OVS-2026-0007'),
    ('bram.coppens@example.be',      'PDD-2027-GENT',  522.50, DATE '2027-08-18', 'overschrijving',   'OVS-2027-0008')
) AS b(email, periode_code, bedrag, datum, methode, referentie)
JOIN persoon           p   ON p.email = b.email
JOIN opleidingsperiode per ON per.code = b.periode_code
JOIN inschrijving      i   ON i.cursist_id = p.persoon_id AND i.periode_id = per.periode_id;


/* ---------------------------------------------------------------------
   13. STATISTIEKEN BIJWERKEN
   Zorgt ervoor dat de query planner de nieuwe indexen meteen gebruikt.
   --------------------------------------------------------------------- */
ANALYZE;


/* ---------------------------------------------------------------------
   CONTROLE
   --------------------------------------------------------------------- */
SELECT 'categorie'           AS tabel, COUNT(*) AS aantal FROM categorie
UNION ALL SELECT 'subcategorie',        COUNT(*) FROM subcategorie
UNION ALL SELECT 'opleiding',           COUNT(*) FROM opleiding
UNION ALL SELECT 'module',              COUNT(*) FROM module
UNION ALL SELECT 'opleidingsperiode',   COUNT(*) FROM opleidingsperiode
UNION ALL SELECT 'periode_module',      COUNT(*) FROM periode_module
UNION ALL SELECT 'persoon',             COUNT(*) FROM persoon
UNION ALL SELECT 'cursist',             COUNT(*) FROM cursist
UNION ALL SELECT 'lesgever',            COUNT(*) FROM lesgever
UNION ALL SELECT 'inschrijving',        COUNT(*) FROM inschrijving
UNION ALL SELECT 'inschrijving_module', COUNT(*) FROM inschrijving_module
UNION ALL SELECT 'evaluatie',           COUNT(*) FROM evaluatie
UNION ALL SELECT 'betaling',            COUNT(*) FROM betaling
UNION ALL SELECT 'inschrijving_log',    COUNT(*) FROM inschrijving_log
ORDER BY tabel;
