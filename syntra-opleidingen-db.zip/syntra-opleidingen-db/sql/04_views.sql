/* =====================================================================
   04_views.sql

   Twee soorten views, herkenbaar aan hun prefix:

     vw_pub_...  PUBLIEK. Dit is alles wat de website mag zien.
                 Bevat geen enkel persoonsgegeven van een cursist.
     vw_int_...  INTERN. Voor de administratie en de lesgevers.
                 Bevat contactgegevens, resultaten en bedragen.

   De rol syntra_web krijgt in 07_rollen_en_rechten.sql enkel rechten op
   de vw_pub-views en op geen enkele tabel. Een view draait namelijk met
   de rechten van zijn eigenaar, dus de website kan via die views lezen
   zonder ooit bij de tabel persoon te kunnen.
   ===================================================================== */

DROP VIEW IF EXISTS vw_pub_categorie      CASCADE;
DROP VIEW IF EXISTS vw_pub_subcategorie   CASCADE;
DROP VIEW IF EXISTS vw_pub_opleiding      CASCADE;
DROP VIEW IF EXISTS vw_pub_programma      CASCADE;
DROP VIEW IF EXISTS vw_pub_startmoment    CASCADE;
DROP VIEW IF EXISTS vw_pub_lesgever       CASCADE;
DROP VIEW IF EXISTS vw_int_cursist        CASCADE;
DROP VIEW IF EXISTS vw_int_lesgever       CASCADE;
DROP VIEW IF EXISTS vw_int_klaslijst      CASCADE;
DROP VIEW IF EXISTS vw_int_lesopdracht    CASCADE;
DROP VIEW IF EXISTS vw_int_resultaat      CASCADE;
DROP VIEW IF EXISTS vw_int_bezetting      CASCADE;
DROP VIEW IF EXISTS vw_int_openstaand     CASCADE;


/* =====================================================================
   PUBLIEKE VIEWS
   ===================================================================== */

-- 1. De themapagina /nl/opleidingen
CREATE VIEW vw_pub_categorie AS
SELECT c.categorie_id
     , c.naam
     , c.slug
     , c.omschrijving
     , c.afbeelding_url
     , '/nl/opleidingen/' || c.slug                     AS url
     , COUNT(DISTINCT s.subcategorie_id)                AS aantal_subcategorieen
     , COUNT(DISTINCT o.opleiding_id)                   AS aantal_opleidingen
     , c.volgorde
FROM      categorie    c
LEFT JOIN subcategorie s ON s.categorie_id    = c.categorie_id AND s.gepubliceerd
LEFT JOIN opleiding    o ON o.subcategorie_id = s.subcategorie_id AND o.gepubliceerd
WHERE     c.gepubliceerd
GROUP BY  c.categorie_id, c.naam, c.slug, c.omschrijving, c.afbeelding_url, c.volgorde
ORDER BY  c.volgorde, c.naam;

COMMENT ON VIEW vw_pub_categorie IS 'Themakaarten op de overzichtspagina van alle opleidingen.';


-- 2. De pagina van een categorie, bv. /nl/opleidingen/grafisch-it-en-media
CREATE VIEW vw_pub_subcategorie AS
SELECT s.subcategorie_id
     , s.categorie_id
     , c.naam                                              AS categorie
     , c.slug                                              AS categorie_slug
     , s.naam
     , s.slug
     , s.omschrijving
     , s.afbeelding_url
     , '/nl/opleidingen/' || c.slug || '/' || s.slug        AS url
     , COUNT(o.opleiding_id)                                AS aantal_opleidingen
     , s.volgorde
FROM      subcategorie s
JOIN      categorie    c ON c.categorie_id = s.categorie_id
LEFT JOIN opleiding    o ON o.subcategorie_id = s.subcategorie_id AND o.gepubliceerd
WHERE     s.gepubliceerd
  AND     c.gepubliceerd
GROUP BY  s.subcategorie_id, s.categorie_id, c.naam, c.slug, c.volgorde,
          s.naam, s.slug, s.omschrijving, s.afbeelding_url, s.volgorde
ORDER BY  c.volgorde, s.volgorde, s.naam;


-- 3. De opleidingskaartjes, met het eerstvolgende startmoment
CREATE VIEW vw_pub_opleiding AS
SELECT o.opleiding_id
     , o.naam
     , o.slug
     , o.korte_omschrijving
     , c.naam                                     AS categorie
     , c.slug                                     AS categorie_slug
     , s.naam                                     AS subcategorie
     , s.slug                                     AS subcategorie_slug
     , v.omschrijving                             AS opleidingsvorm
     , n.omschrijving                             AS niveau
     , o.ai_geintegreerd
     , o.nieuw
     , o.duur_in_jaren
     , '/nl/opleidingen/' || c.slug || '/' || s.slug || '/' || o.slug AS url
       -- Subquery's in de SELECT: per opleiding het eerstvolgende
       -- startmoment, de laagste prijs en de gemeenten waar ze doorgaat.
     , (SELECT MIN(p.startdatum)
        FROM   opleidingsperiode p
        WHERE  p.opleiding_id = o.opleiding_id
          AND  p.status IN ('gepland', 'open')
          AND  p.startdatum >= CURRENT_DATE)      AS eerstvolgende_start
     , (SELECT MIN(p.prijs)
        FROM   opleidingsperiode p
        WHERE  p.opleiding_id = o.opleiding_id
          AND  p.status IN ('gepland', 'open')
          AND  p.startdatum >= CURRENT_DATE)      AS prijs_vanaf
     , (SELECT STRING_AGG(DISTINCT ca.gemeente, ', ')
        FROM   opleidingsperiode p
        JOIN   campus ca ON ca.campus_id = p.campus_id
        WHERE  p.opleiding_id = o.opleiding_id
          AND  p.status IN ('gepland', 'open')
          AND  p.startdatum >= CURRENT_DATE)      AS locaties
FROM opleiding      o
JOIN subcategorie   s ON s.subcategorie_id = o.subcategorie_id
JOIN categorie      c ON c.categorie_id    = s.categorie_id
JOIN opleidingsvorm v ON v.vorm_code       = o.vorm_code
JOIN niveau         n ON n.niveau_code     = o.niveau_code
WHERE o.gepubliceerd
ORDER BY c.volgorde, s.volgorde, o.naam;


-- 4. Het blok "Programma" op een opleidingspagina
CREATE VIEW vw_pub_programma AS
SELECT o.opleiding_id
     , o.slug           AS opleiding_slug
     , o.naam           AS opleiding
     , m.module_id
     , m.code           AS module_code
     , m.naam           AS module
     , m.omschrijving
     , m.aantal_sessies
     , m.vrijstelbaar
     , m.eindproef
     , m.volgorde
FROM module    m
JOIN opleiding o ON o.opleiding_id = m.opleiding_id
WHERE o.gepubliceerd
ORDER BY o.naam, m.volgorde;


-- 5. Het blok "Waar en wanneer?"
CREATE VIEW vw_pub_startmoment AS
SELECT p.periode_id
     , o.opleiding_id
     , o.naam                                            AS opleiding
     , o.slug                                            AS opleiding_slug
     , p.code                                            AS periode_code
     , p.academiejaar
     , ca.naam                                           AS campus
     , ca.adres || ', ' || ca.postcode || ' ' || ca.gemeente AS adres
     , p.startdatum
     , p.einddatum
     , p.dagdeel
     , p.prijs
     , p.status
     , fn_vrije_plaatsen(p.periode_id)                   AS vrije_plaatsen
     , CASE
         WHEN p.status IN ('gepland', 'open')
          AND fn_vrije_plaatsen(p.periode_id) > 0
          AND CURRENT_DATE <= COALESCE(p.inschrijven_tot, p.startdatum)
         THEN TRUE
         ELSE FALSE
       END                                               AS inschrijven_mogelijk
     , p.lessenrooster_url
FROM opleidingsperiode p
JOIN opleiding         o  ON o.opleiding_id = p.opleiding_id
JOIN campus            ca ON ca.campus_id   = p.campus_id
WHERE o.gepubliceerd
  AND p.status <> 'geannuleerd'
ORDER BY o.naam, p.startdatum;


-- 6. Het publieke profiel van een lesgever
-- Let op wat hier NIET in staat: e-mail, telefoon, uurtarief, IBAN,
-- ondernemingsnummer en rijksregisternummer.
CREATE VIEW vw_pub_lesgever AS
SELECT l.lesgever_id
     , p.voornaam
     , p.voornaam || ' ' || p.familienaam AS naam
     , l.publieke_bio
     , l.foto_url
     , l.linkedin_url
FROM lesgever l
JOIN persoon  p ON p.persoon_id = l.lesgever_id
WHERE l.zichtbaar_op_web
  AND l.uit_dienst_op IS NULL
ORDER BY p.familienaam, p.voornaam;


/* =====================================================================
   INTERNE VIEWS
   ===================================================================== */

-- 7. Cursistenfiche met volledige contactgegevens
CREATE VIEW vw_int_cursist AS
SELECT c.cursist_id
     , c.cursistnummer
     , p.voornaam
     , p.familienaam
     , p.email
     , p.telefoon
     , p.geboortedatum
     , fn_leeftijd(p.geboortedatum)      AS leeftijd
     , p.adres
     , p.postcode
     , p.gemeente
     , c.hoogste_diploma
     , c.opleidingscheques
     , c.kmo_portefeuille
     , c.actief
     , c.dossier_sinds
     , (SELECT COUNT(*) FROM inschrijving i WHERE i.cursist_id = c.cursist_id)
                                         AS aantal_inschrijvingen
FROM cursist c
JOIN persoon p ON p.persoon_id = c.cursist_id
ORDER BY p.familienaam, p.voornaam;


-- 8. Lesgeversfiche, inclusief facturatiegegevens
CREATE VIEW vw_int_lesgever AS
SELECT l.lesgever_id
     , l.lesgevernummer
     , p.voornaam
     , p.familienaam
     , p.email
     , p.telefoon
     , l.ondernemingsnummer
     , l.uurtarief
     , l.iban
     , l.in_dienst_sinds
     , l.uit_dienst_op
     , l.zichtbaar_op_web
FROM lesgever l
JOIN persoon  p ON p.persoon_id = l.lesgever_id
ORDER BY p.familienaam, p.voornaam;


-- 9. Klaslijst: wie zit er in welke periode
CREATE VIEW vw_int_klaslijst AS
SELECT p.periode_id
     , p.code                            AS periode_code
     , o.naam                            AS opleiding
     , p.startdatum
     , c.cursistnummer
     , per.voornaam
     , per.familienaam
     , per.email
     , per.telefoon
     , i.inschrijving_id
     , i.status
     , CAST(i.ingeschreven_op AS DATE)   AS ingeschreven_op
     , i.te_betalen
     , fn_openstaand_saldo(i.inschrijving_id) AS openstaand
FROM inschrijving      i
JOIN cursist           c   ON c.cursist_id  = i.cursist_id
JOIN persoon           per ON per.persoon_id = c.cursist_id
JOIN opleidingsperiode p   ON p.periode_id  = i.periode_id
JOIN opleiding         o   ON o.opleiding_id = p.opleiding_id
ORDER BY p.startdatum, o.naam, per.familienaam, per.voornaam;


-- 10. Lesopdrachten: wie geeft welke module, wanneer en voor hoeveel cursisten
CREATE VIEW vw_int_lesopdracht AS
SELECT l.lesgever_id
     , per.voornaam || ' ' || per.familienaam AS lesgever
     , per.email
     , o.naam                                 AS opleiding
     , p.code                                 AS periode_code
     , p.academiejaar
     , m.code                                 AS module_code
     , m.naam                                 AS module
     , m.aantal_sessies
     , pml.rol
     , pm.startdatum
     , pm.einddatum
     , ca.naam                                AS campus
     , (SELECT COUNT(*)
        FROM   inschrijving_module im
        JOIN   inschrijving i ON i.inschrijving_id = im.inschrijving_id
        WHERE  im.periode_module_id = pm.periode_module_id
          AND  i.status IN ('aangevraagd', 'bevestigd', 'afgewerkt'))
                                              AS aantal_cursisten
FROM periode_module_lesgever pml
JOIN periode_module          pm  ON pm.periode_module_id = pml.periode_module_id
JOIN module                  m   ON m.module_id          = pm.module_id
JOIN opleidingsperiode       p   ON p.periode_id         = pm.periode_id
JOIN opleiding               o   ON o.opleiding_id       = p.opleiding_id
JOIN campus                  ca  ON ca.campus_id         = p.campus_id
JOIN lesgever                l   ON l.lesgever_id        = pml.lesgever_id
JOIN persoon                 per ON per.persoon_id       = l.lesgever_id
ORDER BY p.startdatum, m.volgorde, per.familienaam;


-- 11. Resultaten per cursist en module
CREATE VIEW vw_int_resultaat AS
SELECT i.inschrijving_id
     , p.periode_id
     , p.code                              AS periode_code
     , o.naam                              AS opleiding
     , c.cursistnummer
     , per.familienaam || ' ' || per.voornaam AS cursist
     , m.code                              AS module_code
     , m.naam                              AS module
     , im.inschrijving_module_id
     , im.vrijstelling
     , e.poging
     , e.score
     , CASE WHEN e.score IS NULL THEN NULL
            WHEN e.score >= 50   THEN TRUE
            ELSE FALSE
       END                                 AS geslaagd
     , e.evaluatiedatum
     , fn_module_geslaagd(im.inschrijving_module_id) AS module_afgerond
FROM      inschrijving_module im
JOIN      inschrijving        i   ON i.inschrijving_id = im.inschrijving_id
JOIN      cursist             c   ON c.cursist_id      = i.cursist_id
JOIN      persoon             per ON per.persoon_id    = c.cursist_id
JOIN      periode_module      pm  ON pm.periode_module_id = im.periode_module_id
JOIN      module              m   ON m.module_id       = pm.module_id
JOIN      opleidingsperiode   p   ON p.periode_id      = pm.periode_id
JOIN      opleiding           o   ON o.opleiding_id    = p.opleiding_id
LEFT JOIN evaluatie           e   ON e.inschrijving_module_id = im.inschrijving_module_id
ORDER BY o.naam, per.familienaam, m.volgorde, e.poging;


-- 12. Bezetting en verwachte omzet per periode
CREATE VIEW vw_int_bezetting AS
SELECT p.periode_id
     , p.code                                  AS periode_code
     , o.naam                                  AS opleiding
     , p.academiejaar
     , ca.naam                                 AS campus
     , p.startdatum
     , p.status
     , p.max_cursisten
     , fn_aantal_ingeschreven(p.periode_id)    AS ingeschreven
     , fn_vrije_plaatsen(p.periode_id)         AS vrije_plaatsen
     , ROUND(100.0 * fn_aantal_ingeschreven(p.periode_id) / p.max_cursisten, 1)
                                               AS bezetting_pct
     , (SELECT COUNT(*) FROM periode_module pm WHERE pm.periode_id = p.periode_id)
                                               AS aantal_modules
     , (SELECT COALESCE(SUM(i.te_betalen), 0)
        FROM   inschrijving i
        WHERE  i.periode_id = p.periode_id
          AND  i.status <> 'geannuleerd')       AS verwachte_omzet
FROM opleidingsperiode p
JOIN opleiding         o  ON o.opleiding_id = p.opleiding_id
JOIN campus            ca ON ca.campus_id   = p.campus_id
ORDER BY p.startdatum;


-- 13. Openstaande betalingen
CREATE VIEW vw_int_openstaand AS
SELECT i.inschrijving_id
     , c.cursistnummer
     , per.voornaam || ' ' || per.familienaam AS cursist
     , per.email
     , o.naam                                 AS opleiding
     , p.code                                 AS periode_code
     , i.te_betalen
     , COALESCE(SUM(b.bedrag), 0)             AS betaald
     , i.te_betalen - COALESCE(SUM(b.bedrag), 0) AS openstaand
     , MAX(b.betaaldatum)                     AS laatste_betaling
FROM      inschrijving      i
JOIN      cursist           c   ON c.cursist_id   = i.cursist_id
JOIN      persoon           per ON per.persoon_id = c.cursist_id
JOIN      opleidingsperiode p   ON p.periode_id   = i.periode_id
JOIN      opleiding         o   ON o.opleiding_id = p.opleiding_id
LEFT JOIN betaling          b   ON b.inschrijving_id = i.inschrijving_id
WHERE     i.status <> 'geannuleerd'
GROUP BY  i.inschrijving_id, c.cursistnummer, per.voornaam, per.familienaam,
          per.email, o.naam, p.code, i.te_betalen
HAVING    i.te_betalen - COALESCE(SUM(b.bedrag), 0) > 0
ORDER BY  openstaand DESC;


/* ---------------------------------------------------------------------
   CONTROLE
   --------------------------------------------------------------------- */
SELECT table_name AS view
FROM   information_schema.views
WHERE  table_schema = 'public'
ORDER  BY table_name;
