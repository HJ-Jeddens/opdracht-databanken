/* =====================================================================
   00_start_hier.sql
   Syntra MVL - databank opleidingsbeheer
   PostgreSQL / pgAdmin 4

   VOER DIT BESTAND UIT TERWIJL JE VERBONDEN BENT MET DE DATABASE
   "postgres". Je kan geen database aanmaken vanuit de database die je
   op dat moment gebruikt.

   Werkwijze in pgAdmin 4:
     1. Klap je server open in de Browser (links).
     2. Klik op Databases > postgres.
     3. Tools > Query Tool.
     4. Open dit bestand met het mapicoontje en voer het uit (F5).
     5. Rechtsklik op Databases > Refresh. De database
        "syntra_opleidingen" verschijnt nu in de lijst.
     6. Klik die database aan en open een NIEUWE Query Tool.
        Voer daarin de bestanden 01 tot en met 08 uit, in volgorde.

   Alle scripts zijn geschreven voor de Query Tool van pgAdmin. Er zitten
   geen psql-commando's in (geen \i, \echo of \set), zodat je alles
   gewoon kan openen en uitvoeren met F5.
   ===================================================================== */

-- Bestaat de database al van een vorige poging? Dan eerst weg.
-- Let op: hierbij gaat alle data verloren.
DROP DATABASE IF EXISTS syntra_opleidingen;

CREATE DATABASE syntra_opleidingen
    WITH ENCODING = 'UTF8'
         TEMPLATE = template0
         LC_COLLATE = 'C'
         LC_CTYPE = 'C';

COMMENT ON DATABASE syntra_opleidingen
    IS 'Opleidingsbeheer Syntra MVL - opdracht module Databanken';

-- Controle: de database staat nu in de lijst.
SELECT datname AS database
FROM   pg_database
WHERE  datname = 'syntra_opleidingen';
