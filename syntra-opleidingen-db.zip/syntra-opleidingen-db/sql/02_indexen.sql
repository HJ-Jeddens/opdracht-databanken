/* =====================================================================
   02_indexen.sql

   Een PRIMARY KEY en een UNIQUE-constraint krijgen automatisch een index.
   Een FOREIGN KEY NIET. Daarom staan hier vooral indexen op de
   foreign-keykolommen: elke join en elke DELETE of UPDATE op de
   oudertabel loopt daarover.
   ===================================================================== */

DROP INDEX IF EXISTS idx_subcategorie_categorie;
DROP INDEX IF EXISTS idx_opleiding_subcategorie;
DROP INDEX IF EXISTS idx_opleiding_vorm;
DROP INDEX IF EXISTS idx_opleiding_niveau;
DROP INDEX IF EXISTS idx_opleiding_naam;
DROP INDEX IF EXISTS idx_module_opleiding;
DROP INDEX IF EXISTS idx_periode_opleiding;
DROP INDEX IF EXISTS idx_periode_campus;
DROP INDEX IF EXISTS idx_periode_startdatum;
DROP INDEX IF EXISTS idx_periode_module_periode;
DROP INDEX IF EXISTS idx_periode_module_module;
DROP INDEX IF EXISTS idx_pml_lesgever;
DROP INDEX IF EXISTS idx_persoon_naam;
DROP INDEX IF EXISTS idx_inschrijving_cursist;
DROP INDEX IF EXISTS idx_inschrijving_periode;
DROP INDEX IF EXISTS idx_im_inschrijving;
DROP INDEX IF EXISTS idx_im_periode_module;
DROP INDEX IF EXISTS idx_evaluatie_im;
DROP INDEX IF EXISTS idx_evaluatie_lesgever;
DROP INDEX IF EXISTS idx_betaling_inschrijving;
DROP INDEX IF EXISTS idx_log_inschrijving;


/* --- Catalogus ------------------------------------------------------- */

-- De website haalt de subcategorieen van een categorie op, gesorteerd
-- op volgorde. Beide kolommen in de index: de sortering hoeft dan niet
-- meer apart te gebeuren.
CREATE INDEX idx_subcategorie_categorie ON subcategorie (categorie_id, volgorde);

CREATE INDEX idx_opleiding_subcategorie ON opleiding (subcategorie_id);
CREATE INDEX idx_opleiding_vorm         ON opleiding (vorm_code);
CREATE INDEX idx_opleiding_niveau       ON opleiding (niveau_code);

-- Zoeken op naam zonder rekening te houden met hoofdletters.
CREATE INDEX idx_opleiding_naam ON opleiding (LOWER(naam));

CREATE INDEX idx_module_opleiding ON module (opleiding_id, volgorde);

CREATE INDEX idx_periode_opleiding ON opleidingsperiode (opleiding_id, startdatum);
CREATE INDEX idx_periode_campus    ON opleidingsperiode (campus_id);

-- Partiele index: de startmomenten op de website zijn altijd periodes
-- die nog opengaan. De index blijft daardoor klein.
CREATE INDEX idx_periode_startdatum ON opleidingsperiode (startdatum)
    WHERE status IN ('gepland', 'open');

CREATE INDEX idx_periode_module_periode ON periode_module (periode_id, volgorde);
CREATE INDEX idx_periode_module_module  ON periode_module (module_id);
CREATE INDEX idx_pml_lesgever           ON periode_module_lesgever (lesgever_id);


/* --- Personen -------------------------------------------------------- */

CREATE INDEX idx_persoon_naam ON persoon (LOWER(familienaam), LOWER(voornaam));


/* --- Inschrijvingen -------------------------------------------------- */

CREATE INDEX idx_inschrijving_cursist ON inschrijving (cursist_id);
CREATE INDEX idx_inschrijving_periode ON inschrijving (periode_id, status);

CREATE INDEX idx_im_inschrijving   ON inschrijving_module (inschrijving_id);
CREATE INDEX idx_im_periode_module ON inschrijving_module (periode_module_id);

CREATE INDEX idx_evaluatie_im       ON evaluatie (inschrijving_module_id);
CREATE INDEX idx_evaluatie_lesgever ON evaluatie (lesgever_id);

CREATE INDEX idx_betaling_inschrijving ON betaling (inschrijving_id);
CREATE INDEX idx_log_inschrijving      ON inschrijving_log (inschrijving_id);


/* ---------------------------------------------------------------------
   CONTROLE
   --------------------------------------------------------------------- */
SELECT tablename AS tabel, indexname AS index
FROM   pg_indexes
WHERE  schemaname = 'public'
ORDER  BY tablename, indexname;
